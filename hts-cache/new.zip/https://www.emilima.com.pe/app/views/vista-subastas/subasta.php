
<!-- Head & Header -->
        <!DOCTYPE html>
        <html lang="es">

        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">

            <meta name="author" content="subasta, emilima">

            <title>
                Emilima - Subasta            </title>

            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
            <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
            <link rel="stylesheet" href="/app/assets/css/accesibility.css"
            <link rel="shortcut icon" href="favicon.ico">
            <script src="/app/assets/jQuery/jquery.min.js"></script>
            <!-- Dynamic Styles -->
                            <link rel="stylesheet" href="/app/assets/markdown/markdown.css" />
            
            
            <!-- Main Style -->
            <link rel="stylesheet" href="/app/assets/css/main.css">
            <!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=G-RXX2LDLSCV"></script>
            <script>
                window.dataLayer = window.dataLayer || [];

                function gtag() {
                    dataLayer.push(arguments);
                }
                gtag('js', new Date());

                gtag('config', 'G-RXX2LDLSCV');
            </script>
            <script src="https://kit.fontawesome.com/73a9e59589.js"></script>
        </head>
                
        <body>
            <div id="app">
            <!-- Header top -->
        <div class="bg-eee app-header-top">
            <div class="app-container-fluid h-100">
                <div class="d-flex">
                    <a class="app-left-link" target="_blank" href="" title="Mesa de partes virtual">
                        <img draggable="false" height="20" src="https://www.emilima.com.pe//app/assets/img/website-icon.png" alt="website icono">
                        <span>Mesa de Partes</span>
                    </a>
                    <a class="app-left-link" target="_blank" href="http://sgd.emilima.com.pe/denuncias.html" title="Inquietudes y Denuncias" style="margin-left: 8px;">
                        <img draggable="false" height="20" src="https://www.emilima.com.pe//app/assets/img/antisoborno.png" alt="antisoborno icono">
                        <span>Denuncia SGAS</span>
                    </a>
                </div>
                <div class="d-flex align-items-center">
                    <ul role="list" class="app-contact-links-top">
                                            </ul>
                    <a class="center-sub-items" title="Portal de transparencia Emilima" target="_blank" href="">
                        <img src="https://www.emilima.com.pe//app/assets/img/lupa-transparencia.png" height="25" alt="lupa portal transparencia">
                    </a>
                </div>
            </div>
        </div>
        <!-- Main Header -->
        <header class="app-header">

            <div class="app-container app-header-row">

                <a class="app-logo-link" href="">
                    <img draggable="false" src="https://www.emilima.com.pe//app/assets/img/logo-emilima-color.png" alt="Logo Emilima">
                </a>
                <div class="d-flex">
                    <nav id="desktop-menu" class="app-menu">

                        <!-- PRIMER NIVEL -->
                        <ul>

                            
                                <li class="app-menu-dropdown megamenu-activator">
                                                                            <a class="app-menu-link" href="#">
                                            <span>
                                                Institucional                                            </span>
                                            <svg width="12" height="8">
                                                <use xlink:href="#arrow-down">
                                            </svg>
                                        </a>

                                                                                    <div class="megamenu d-flex">
                                                <ul class="bg-white app-container">
                                                                                                            <li>
                                                            <a href="/acerca-de-nosotros" class="app-menu-link">
                                                                <span> Datos Generales </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#about-us-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                            <li>
                                                            <a href="/marco-legal" class="app-menu-link">
                                                                <span> Marco Legal </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#law-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                            <li>
                                                            <a href="/estructura-organica" class="app-menu-link">
                                                                <span> Estructura Orgánica </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#org-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                            <li>
                                                            <a href="/funcionarios" class="app-menu-link">
                                                                <span> Funcionarios </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#employees-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                            <li>
                                                            <a href="/denuncias" class="app-menu-link">
                                                                <span> ISO 37001 </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#denunciation-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                    </ul>
                                            </div>
                                        
                                    
                                </li>

                            
                                <li class="app-menu-dropdown megamenu-activator">
                                                                            <a class="app-menu-link" href="#">
                                            <span>
                                                Servicios                                            </span>
                                            <svg width="12" height="8">
                                                <use xlink:href="#arrow-down">
                                            </svg>
                                        </a>

                                                                                    <div class="megamenu d-flex">
                                                <ul class="bg-white app-container">
                                                                                                            <li>
                                                            <a href="/servicios/administracion-y-saneamiento-de-inmuebles" class="app-menu-link">
                                                                <span> Administración Y Saneamiento de Inmuebles </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#inmuebles-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                            <li>
                                                            <a href="#" class="app-menu-link">
                                                                <span> Servicio de Promoción Inmobiliaria </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#inmobiliaria-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                            <li>
                                                            <a href="/servicios/subastas" class="app-menu-link">
                                                                <span> Subasta pública de inmuebles </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#subasta-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                            <li>
                                                            <a href="/servicios/desarrollo-tecnologico" class="app-menu-link">
                                                                <span> Desarrollo Tecnológico </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#consultoria-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                            <li>
                                                            <a href="/servicios/obras" class="app-menu-link">
                                                                <span> Ejecución de Obras Públicas </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#obras-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                            <li>
                                                            <a href="/servicios/fondo-editorial" class="app-menu-link">
                                                                <span> Fondo Editorial </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#editorial-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                    </ul>
                                            </div>
                                        
                                    
                                </li>

                            
                                <li class="app-menu-dropdown megamenu-activator">
                                                                            <a class="app-menu-link" href="#">
                                            <span>
                                                Prensa                                            </span>
                                            <svg width="12" height="8">
                                                <use xlink:href="#arrow-down">
                                            </svg>
                                        </a>

                                                                                    <div class="megamenu d-flex">
                                                <ul class="bg-white app-container">
                                                                                                            <li>
                                                            <a href="/prensa/notas-de-prensa" class="app-menu-link">
                                                                <span> Notas de prensa </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#inmuebles-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                            <li>
                                                            <a href="/prensa/comunicados" class="app-menu-link">
                                                                <span> Comunicados </span>
                                                                <svg width="50" height="40">
                                                                    <use xlink:href="#inmobiliaria-icon">
                                                                </svg>
                                                            </a>
                                                        </li>

                                                                                                    </ul>
                                            </div>
                                        
                                    
                                </li>

                            
                                <li class="app-menu-dropdown ">
                                                                            <a class="app-menu-link" href="#">
                                            <span>
                                                Transparencia                                            </span>
                                            <svg width="12" height="8">
                                                <use xlink:href="#arrow-down">
                                            </svg>
                                        </a>

                                                                                    <!-- TRANSPARENCIA -->
                                            <ul class="dropdown">

                                                
                                            </ul>
                                        
                                    
                                </li>

                            
                                <li class=" ">
                                                                            <a class="app-menu-link" href="/contactanos">
                                            <span>
                                                Contáctanos                                            </span>
                                        </a>
                                    
                                </li>

                            
                        </ul>
                    </nav>
                    <!-- <a id="btn-transparence" href="https://www.transparencia.gob.pe/enlaces/pte_transparencia_enlaces.aspx?id_entidad=13697" target="_blank">
                        <img draggable="false" src="/app/assets/img/portal-transparencia.png" alt="portal transparencia">
                    </a> -->
                    <button id="btn-hamburger" role="button" class="bg-white ml-4" aria-label="Presiona para ver menú">
                        <svg class="hamburger" width="24" height="16">
                            <use xlink:href="#hamburger">
                        </svg>
                        <svg class="close" width="24" height="16">
                            <use xlink:href="#btn-close">
                        </svg>
                    </button>
                </div>

            </div>

            <div id="overlay-menu" class="overlay-menu"></div>

            <nav id="responsive-menu" class="responsive-menu">
                <ul role="list" id="wrapper-responsive-menu" class="menu-responsive-wrapper">

                </ul>
                <div class="transparence">
                    <a href="https://www.transparencia.gob.pe/enlaces/pte_transparencia_enlaces.aspx?id_entidad=13697" target="_blank">
                        <img draggable="false" src="https://www.emilima.com.pe//app/assets/img/portal-transparencia.png" alt="portal transparencia">
                    </a>
                </div>
            </nav>

        </header>

        <script>
            $(document).ready(function() {
                const wrapper = document.querySelector("#wrapper-responsive-menu");
                const dataList = [{"name":"Institucional","path":"#","mode":"megamenu","submenu":[{"name":"Datos Generales","path":"\/acerca-de-nosotros","icon":"about-us-icon"},{"name":"Marco Legal","path":"\/marco-legal","icon":"law-icon"},{"name":"Estructura Org\u00e1nica","path":"\/estructura-organica","icon":"org-icon"},{"name":"Funcionarios","path":"\/funcionarios","icon":"employees-icon"},{"name":"ISO 37001","path":"\/denuncias","icon":"denunciation-icon"}]},{"name":"Servicios","path":"#","mode":"megamenu","submenu":[{"name":"Administraci\u00f3n Y Saneamiento de Inmuebles","path":"\/servicios\/administracion-y-saneamiento-de-inmuebles","icon":"inmuebles-icon"},{"name":"Servicio de Promoci\u00f3n Inmobiliaria","path":"#","icon":"inmobiliaria-icon"},{"name":"Subasta p\u00fablica de inmuebles","path":"\/servicios\/subastas","icon":"subasta-icon"},{"name":"Desarrollo Tecnol\u00f3gico","path":"\/servicios\/desarrollo-tecnologico","icon":"consultoria-icon"},{"name":"Ejecuci\u00f3n de Obras P\u00fablicas","path":"\/servicios\/obras","icon":"obras-icon"},{"name":"Fondo Editorial","path":"\/servicios\/fondo-editorial","icon":"editorial-icon"}]},{"name":"Prensa","path":"#","mode":"megamenu","submenu":[{"name":"Notas de prensa","path":"\/prensa\/notas-de-prensa","icon":"inmuebles-icon"},{"name":"Comunicados","path":"\/prensa\/comunicados","icon":"inmobiliaria-icon"}]},{"name":"Transparencia","path":"#","submenu":[{"name":"Datos Generales","path":"#","submenu":[{"name":"Resoluciones de Gerencia","path":"\/transparencia\/datos-generales\/resoluciones-gerencia","key":"resoluciones-gerencia","type":"table"},{"name":"Directivas","path":"\/transparencia\/datos-generales\/directivas","key":"directivas","type":"table"},{"name":"Instructivos","path":"\/transparencia\/datos-generales\/instructivos","key":"directivas","type":"table"},{"name":"Guias","path":"\/transparencia\/datos-generales\/guias","key":"directivas","type":"table"},{"name":"Reglamentos","path":"\/transparencia\/datos-generales\/reglamentos","key":"directivas","type":"table"},{"name":"Memorias Anuales","path":"\/transparencia\/datos-generales\/memorias-anuales","key":"memorias-anuales","type":"memory-yearly-list"}]},{"name":"Planeamiento y Organizaci\u00f3n","path":"#","submenu":[{"name":"PAP","path":"\/transparencia\/planeamiento-organizacion\/pap","key":"pap","title":"Presupuesto Analitico de Personal","type":"list"},{"name":"MOF","path":"\/transparencia\/planeamiento-organizacion\/mof","key":"mof","title":"Manual de Organizaci\u00f3n y Funciones","type":"list"},{"name":"ROF","path":"\/transparencia\/planeamiento-organizacion\/rof","key":"rof","title":"Reglamento de Organizaci\u00f3n y Funciones","type":"list"},{"name":"CAP","path":"\/transparencia\/planeamiento-organizacion\/cap","key":"cap","title":"Cuadro para Asignacion de Personal","type":"list"},{"name":"POI","path":"\/transparencia\/planeamiento-organizacion\/poi","key":"poi","title":"PLAN OPERATIVO INSTITUCIONAL","type":"list"},{"name":"PEI","path":"\/transparencia\/planeamiento-organizacion\/pei","key":"pei","title":"Plan Estrat\u00e9gico Institucional","type":"list"},{"name":"Indicadores de Desempe\u00f1o","path":"\/transparencia\/planeamiento-organizacion\/indicadores-desempe\u00f1o","key":"indicadores-desempe\u00f1o","title":"Indicadores de Desempe\u00f1o","type":"list"},{"name":"Manual de Procedimientos","path":"\/transparencia\/planeamiento-organizacion\/manual-procedimientos","key":"manual-procedimientos","title":"Manual de Procedimientos","type":"list"},{"name":"Plan Operativo Informatico","path":"\/transparencia\/planeamiento-organizacion\/poi-informatico","key":"poi-informatico","title":"Plan Operativo Informatico","type":"list"}]},{"name":"Informaci\u00f3n Presupuestal","path":"#","submenu":[{"name":"PIA - PIM","path":"\/transparencia\/informacion-presupuestal\/pia-pim","key":"pia-pim","type":"list"},{"name":"Balance general","path":"\/transparencia\/informacion-presupuestal\/balance-general","key":"balance-general","type":"list"}]}]},{"name":"Cont\u00e1ctanos","path":"\/contactanos"}];
                const transparencyData = null;

                dataList[3].submenu = transparencyData.map((submenu1) => {
                    let parserSubmenu = submenu1
                    parserSubmenu.submenu = parserSubmenu.submenu.map((submenu2) => {
                        return {
                            ...submenu2,
                            path: `/transparencia/${parserSubmenu.slug}/${submenu2.slug}`
                        }
                    })
                    return {
                        ...parserSubmenu,
                        path: '#'
                    }
                })

                let lastParent = dataList;
                let currentChild = null;
                let isFirstParent = false;

                renderList(wrapper, dataList);

                function renderList(wrapper, list) {
                    if (list[0].mode) {
                        isFirstParent = true;
                    } else {
                        isFirstParent = false;
                    }
                    wrapper.innerHTML = "";
                    renderButtonBackAndInfo(dataList);
                    lastParent = list;
                    list.forEach(item => {
                        wrapper.appendChild(renderItemLI(item));
                    })
                }

                function renderButtonBackAndInfo(lastP) {
                    if (isFirstParent) return;
                    const LI = document.createElement("LI");
                    LI.classList.add("button-container")
                    const BUTTON = document.createElement("A");
                    BUTTON.setAttribute("href", "#")
                    const SPAN = document.createElement("SPAN")
                    SPAN.innerText = currentChild.name;
                    BUTTON.innerHTML = `
                        <svg width="12" height="10">
                            <use xlink:href="#arrow-left">
                        </svg>
                    `;
                    LI.appendChild(BUTTON);
                    LI.appendChild(SPAN)
                    LI.addEventListener("click", (ev) => {
                        ev.preventDefault();
                        renderList(wrapper, lastP)
                    })
                    wrapper.appendChild(LI);
                }


                function renderItemLI(item) {
                    const LI = document.createElement("LI");
                    LI.classList.add("menu-item-container");
                    const A = document.createElement("A");
                    A.classList.add("menu-item-link");
                    A.setAttribute("href", item.path)
                    if (item.submenu && item.submenu.length > 0) {
                        A.addEventListener("click", (ev) => handleDropdownClick(ev, item))
                        currentChild = item
                    }
                    A.innerHTML +=
                        `<div class="d-flex align-items-center">
                            ${
                                item.icon
                                ? `
                                <svg style="width: 50px; height: 50px; transform: scale(0.75)">
                                    <use xlink:href="#${item.icon}">
                                </svg>
                                ` : ''
                            }
                            <span>${item.name}</span>
                        </div>
                    ${
                        item.submenu && item.submenu.length > 0 
                        ? `
                        <svg width="12" height="10">
                            <use xlink:href="#arrow-right">
                        </svg>
                        `
                        : ''
                    }`
                    LI.appendChild(A);
                    return LI;
                }

                function handleDropdownClick(ev, item) {
                    ev.preventDefault();
                    currentChild = item;
                    renderList(wrapper, item.submenu)
                }
            });
        </script>


<section class="app-first-content bg-eee pt-0 pb-0 cover-secondary">
    <img draggable="false" src="" alt="">
    <h1 class="cover-title app-container"></h1>
</section>

<section class="app-padding-section pt-3 pb-0 mb-0">
    <div class="app-container">
        <!-- Navigation -->
        <ul role="navigation" class="navigation-section pb-3">
            <li class="navigation-item">
                <a href="/"><span>Inicio</span></a>
                <svg width="7" height="9">
                    <use xlink:href="#arrow-navigation">
                </svg>
            </li>
            <li class="navigation-item">
                <a href="#"><span>Servicios</span></a>
                <svg width="7" height="9">
                    <use xlink:href="#arrow-navigation">
                </svg>
            </li>
            <li class="navigation-item">
                <a href="/servicios/subastas"><span>Subasta pública de inmuebles</span></a>
                <svg width="7" height="9">
                    <use xlink:href="#arrow-navigation">
                </svg>
            </li>
            <li class="navigation-item">
                <a class="active" href="">
                    No se encontró                </a>
            </li>
        </ul>
    </div>
</section>


    <section class="app-padding-section pt-3 pb-3 mt-0">
        <div class="detail-subasta mb-5 d-flex justify-content-center">
            <h4 class="text-center p-5 f-bold text-center c-primary-2 mb-0">
                NO SE CUENTA CON ALGUNA SUBASTA ACTIVA
            </h4>
        </div>
    </section>


<script type="text/javascript">

</script>


<!-- FOOTER -->
        <footer class="bg-eee app-footer">
            <div class="bg-blue">
                <div class="app-container">
                    <div class="app-contact-footer">
                        <div class="app-contact-section">
                            <div class="center-sub-items">
                                <img draggable="false" src="" alt="Logo Emilima SA">
                            </div>
                            <p>
                                <strong>Dirección</strong>
                                <span></span>
                            </p>
                            <p>
                                <strong>Teléfono</strong>
                                <span></span>
                            </p>
                            <p>
                                <strong>Correo electrónico</strong>
                                <span></span>
                            </p>
                            <!-- <div class="app-footer-special-link-container">
                                <a target="_blank" href="http://sgd.emilima.com.pe/mesapartesvirtual.html">
                                    <img draggable="false" src="https://www.emilima.com.pe//app/assets/img/website-icon.png" alt="website icono">
                                    <span>Mesa de Partes Virtual</span>
                                </a>
                            </div> -->
                            <a class="text-decoration-none text-white" href="https://aplicativos.munlima.gob.pe/extranet/siresu/" target="_blank">
                                <p>Libro de Reclamaciones Virtual</p>            
                            </a>
                        </div>
                        <div class="app-contact-section">
                            <h4 class="app-footer-subtitle">
                                Acerca de
                            </h4>

                            <ul role="list" class="app-contact-links">
                                <li>
                                    <a href="../acerca-de-nosotros"><span>Quienes somos</span></a>
                                </li>
                                <li>
                                    <a href="https://www.transparencia.gob.pe/enlaces/pte_transparencia_enlaces.aspx?id_entidad=13697#.YafRNVm22Uk"><span>Transparencia</span></a>
                                </li>
                                <li>
                                    <a href="../estructura-organica"><span>Organigrama</span></a>
                                </li>
                                <li>
                                    <a href="../funcionarios"><span>Funcionarios</span></a>
                                </li>
                            </ul>

                        </div>
                        <div class="app-contact-section">
                            <h4 class="app-footer-subtitle">
                                Servicios
                            </h4>
                            <ul role="list" class="app-contact-links">
                                <li>
                                    <a href="./../servicios/administracion-y-saneamiento-de-inmuebles"><span>Administración de Inmuebles</span></a>
                                </li>
                                <li>
                                    <a href="#"><span>Promoción Inmobiliaria</span></a>
                                </li>
                                <li>
                                    <a href="./../subastas/subasta.php"><span>Subastas</span></a>
                                </li>
                                <li>
                                    <a href="./../servicios/desarrollo-tecnologico"><span>Desarrollo Tecnológico</span></a>
                                </li>
                                <li>
                                    <a href="./../servicios/obras"><span>Obras Públicas</span></a>
                                </li>
                                <li>
                                    <a href="./../servicios/fondo-editorial"><span>Fondo Editorial</span></a>
                                </li>
                            </ul>
                        </div>
                        <div class="app-contact-section">
                            <h4 class="app-footer-subtitle">
                                Redes Sociales
                            </h4>
                            <ul role="list" class="app-contact-links">
                                                            </ul>

                        </div>
                        <div class="app-contact-section app-muni-logo center-sub-items flex-x-end">
                            <img draggable="false" src="" alt="Logo Municipalidad de Lima">
                        </div>
                    </div>
                </div>
            </div>
            <div class="app-container ">
                <p class="app-text-copyright">
                    <span>© Copyright 2021. Todos los derechos reservados.</span>
                    <span class="app-author">Desarrollado por EMILIMA</span>
                </p>
            </div>
        </footer>

        <!-- Global SVG'S -->
        <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
            <symbol id="arrow-down" viewBox="0 0 12 8">
                <path d="M1.41 0.579987L6 5.16999L10.59 0.579987L12 1.99999L6 7.99999L0 1.99999L1.41 0.579987Z" />
            </symbol>
            <symbol id="arrow-left" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M16.67 0l2.83 2.829-9.339 9.175 9.339 9.167-2.83 2.829-12.17-11.996z" />
            </symbol>
            <symbol id="arrow-right" viewBox="0 0 24 24">
                <path d="M5 3l3.057-3 11.943 12-11.943 12-3.057-3 9-9z" />
            </symbol>
            <symbol id="books" viewBox="0 0 24 24">
                <path d="M8.25 0.75V19.5H12V0.75H8.25ZM12 3.25L17 19.5L20.75 18.25L15.75 2L12 3.25ZM3.25 3.25V19.5H7V3.25H3.25ZM0.75 20.75V23.25H23.25V20.75H0.75Z" />
            </symbol>
            <symbol id="hamburger" viewBox="0 0 24 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0.75 0.5H23.25V3H0.75V0.5ZM0.75 6.75H23.25V9.25H0.75V6.75ZM0.75 13H23.25V15.5H0.75V13Z" fill="#004D86" />
            </symbol>
            <symbol id="btn-close" width="18" height="18" viewBox="0 0 18 18" fill="#004d86" xmlns="http://www.w3.org/2000/svg">
                <path d="M17.75 2.0125L15.9875 0.25L9 7.2375L2.0125 0.25L0.25 2.0125L7.2375 9L0.25 15.9875L2.0125 17.75L9 10.7625L15.9875 17.75L17.75 15.9875L10.7625 9L17.75 2.0125Z" />
            </symbol>
            <symbol id="pdf-icon" viewBox="0 0 41 41">
                <path d="M39.7965 32.9922H38.5977V3.60352C38.5977 1.61654 36.9811 0 34.9941 0H10.9707C8.98372 0 7.36719 1.61654 7.36719 3.60352V6.56641H3.60352C1.61654 6.56641 0 8.18294 0 10.1699V21.3809C0 23.3678 1.61654 24.9844 3.60352 24.9844H7.36719V37.3965C7.36719 39.3835 8.98372 41 10.9707 41H34.9941C35.3448 41 35.6779 40.8467 35.9062 40.5806L40.7085 34.9751C41.3764 34.1959 40.8227 32.9922 39.7965 32.9922ZM3.60352 22.582C2.94119 22.582 2.40234 22.0432 2.40234 21.3809V10.1699C2.40234 9.5076 2.94119 8.96875 3.60352 8.96875H26.8262C27.4885 8.96875 28.0273 9.5076 28.0273 10.1699V21.3809C28.0273 22.0432 27.4885 22.582 26.8262 22.582H3.60352ZM29.2774 34.9751L32.3826 38.5977H10.9707C10.3084 38.5977 9.76953 38.0588 9.76953 37.3965V24.9844H26.8262C28.8132 24.9844 30.4297 23.3678 30.4297 21.3809V10.1699C30.4297 8.18294 28.8132 6.56641 26.8262 6.56641H9.76953V3.60352C9.76953 2.94119 10.3084 2.40234 10.9707 2.40234H34.9941C35.6565 2.40234 36.1953 2.94119 36.1953 3.60352V25.7852H32.5918C31.9284 25.7852 31.3906 26.323 31.3906 26.9863V32.9922H30.1895C29.1633 32.9922 28.6096 34.1959 29.2774 34.9751ZM34.9941 37.9531L32.7874 35.3787C33.3577 35.2852 33.793 34.7901 33.793 34.1934V28.1875H36.1953V34.1934C36.1953 34.7901 36.6305 35.2852 37.2009 35.3787L34.9941 37.9531Z" fill="#E83964" />
                <path d="M25.0591 10.9707H21.8135C21.3712 10.9707 21.0127 11.3292 21.0127 11.7715V19.7793C21.0127 20.2392 21.4004 20.6085 21.8667 20.5784C22.2923 20.5508 22.6143 20.1784 22.6143 19.7519V16.5003H24.7738C25.2003 16.5003 25.5727 16.1784 25.6003 15.7528C25.6305 15.2864 25.2612 14.8988 24.8013 14.8988H22.6143V12.5723H25.0317C25.4582 12.5723 25.8307 12.2503 25.8582 11.8247C25.8884 11.3584 25.519 10.9707 25.0591 10.9707Z" fill="#E83964" />
                <path d="M15.375 10.972H13.1084C12.6656 10.972 12.3069 11.3312 12.3076 11.774C12.3105 13.5841 12.3175 17.9696 12.3208 19.7795C12.3216 20.2224 12.6817 20.5804 13.1245 20.5788C13.9093 20.5759 15.0439 20.5708 15.4554 20.5636C16.6258 20.5432 17.6678 20.0132 18.3893 19.0715C19.0473 18.2128 19.4096 17.0427 19.4096 15.7766C19.4096 12.9028 17.7882 10.972 15.375 10.972ZM15.4275 18.9623C15.0843 18.9683 14.4415 18.9729 13.9214 18.9759C13.9183 18.0323 13.911 13.5523 13.9093 12.5735H15.3751C17.1689 12.5735 17.8081 14.2282 17.8081 15.7767C17.808 17.2909 17.0631 18.9337 15.4275 18.9623Z" fill="#E83964" />
                <path d="M7.60071 10.9707H5.37109C4.92882 10.9707 4.57031 11.3292 4.57031 11.7715V19.7793C4.57031 20.2392 4.95797 20.6085 5.42435 20.5784C5.84996 20.5508 6.17187 20.1784 6.17187 19.7519V17.0974C6.66708 17.0947 7.27391 17.0919 7.60079 17.0919C9.31278 17.0919 10.7057 15.7189 10.7057 14.0314C10.7057 12.3438 9.31278 10.9707 7.60071 10.9707ZM7.60071 15.4903C7.27535 15.4903 6.67645 15.4931 6.18285 15.4957C6.1802 14.9869 6.17572 13.1023 6.1742 12.5722H7.60071C8.41558 12.5722 9.10402 13.2404 9.10402 14.0312C9.10402 14.8221 8.41558 15.4903 7.60071 15.4903Z" fill="#E83964" />
            </symbol>
            <symbol id="download-icon" viewBox="0 0 24 24">
                <path d="M16 11h5l-9 10-9-10h5v-11h8v11zm1 11h-10v2h10v-2z" />
            </symbol>
            <symbol id="arrow-navigation" viewBox="0 0 4 6" fill="none">
                <path d="M0.579102 4.90833L2.48743 3L0.579102 1.0875L1.1666 0.5L3.6666 3L1.1666 5.5L0.579102 4.90833Z" fill="#6C757D" />
            </symbol>

            <symbol id="search-icon" width="25" height="25" viewBox="0 0 25 25" fill="none">
                <path d="M9.28571 0C11.7484 0 14.1103 0.978313 15.8517 2.71972C17.5931 4.46113 18.5714 6.82299 18.5714 9.28571C18.5714 11.5857 17.7286 13.7 16.3429 15.3286L16.7286 15.7143H17.8571L25 22.8571L22.8571 25L15.7143 17.8571V16.7286L15.3286 16.3429C13.7 17.7286 11.5857 18.5714 9.28571 18.5714C6.82299 18.5714 4.46113 17.5931 2.71972 15.8517C0.978313 14.1103 0 11.7484 0 9.28571C0 6.82299 0.978313 4.46113 2.71972 2.71972C4.46113 0.978313 6.82299 0 9.28571 0ZM9.28571 2.85714C5.71429 2.85714 2.85714 5.71429 2.85714 9.28571C2.85714 12.8571 5.71429 15.7143 9.28571 15.7143C12.8571 15.7143 15.7143 12.8571 15.7143 9.28571C15.7143 5.71429 12.8571 2.85714 9.28571 2.85714Z" fill="#6C757D" />
            </symbol>

            <symbol id="arrow-next" width="19" height="30" viewBox="0 0 19 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0.475098 26.45L11.9251 15L0.475098 3.525L4.0001 0L19.0001 15L4.0001 30L0.475098 26.45Z" fill="#004D86" />
            </symbol>

            <symbol id="arrow-prev" width="19" height="30" viewBox="0 0 19 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18.525 3.55L7.07503 15L18.525 26.475L15 30L2.80142e-05 15L15 -3.08165e-07L18.525 3.55Z" fill="#004D86" />
            </symbol>
            <!-- Megamenu Icons -->
            <symbol id="about-us-icon" width="48" height="44" viewBox="0 0 48 44">
                <path d="M47.4375 9.50003V11.0625C47.4375 11.2697 47.3552 11.4684 47.2087 11.615C47.0622 11.7615 46.8634 11.8438 46.6562 11.8438H44.3125V13.0157C44.3125 13.6628 43.7878 14.1875 43.1406 14.1875H4.85938C4.21221 14.1875 3.6875 13.6628 3.6875 13.0157V11.8438H1.34375C1.13655 11.8438 0.937836 11.7615 0.791323 11.615C0.64481 11.4684 0.5625 11.2697 0.5625 11.0625V9.50003C0.562501 9.34547 0.608347 9.19438 0.694238 9.06588C0.780129 8.93738 0.902205 8.83725 1.04502 8.77815L23.7013 0.184401C23.8925 0.105199 24.1075 0.105199 24.2987 0.184401L46.955 8.77815C47.0978 8.83725 47.2199 8.93738 47.3058 9.06588C47.3917 9.19438 47.4375 9.34547 47.4375 9.50003ZM45.0938 39.1875H2.90625C1.61182 39.1875 0.5625 40.2368 0.5625 41.5313V43.0938C0.5625 43.301 0.64481 43.4997 0.791323 43.6462C0.937836 43.7927 1.13655 43.875 1.34375 43.875H46.6562C46.8634 43.875 47.0622 43.7927 47.2087 43.6462C47.3552 43.4997 47.4375 43.301 47.4375 43.0938V41.5313C47.4375 40.2368 46.3882 39.1875 45.0938 39.1875ZM8.375 15.75V34.5H4.85938C4.21221 34.5 3.6875 35.0247 3.6875 35.6719V37.625H44.3125V35.6719C44.3125 35.0247 43.7878 34.5 43.1406 34.5H39.625V15.75H33.375V34.5H27.125V15.75H20.875V34.5H14.625V15.75H8.375Z" />
            </symbol>
            <symbol id="law-icon" width="50" height="40" viewBox="0 0 50 40">
                <path d="M20 26.25H19.9984C19.9984 24.9859 20.1031 25.568 13.3539 12.0695C11.975 9.3125 8.02656 9.30703 6.64531 12.0695C-0.160938 25.6836 0.0015625 25.0258 0.0015625 26.25H0C0 29.7016 4.47734 32.5 10 32.5C15.5227 32.5 20 29.7016 20 26.25ZM10 13.75L15.625 25H4.375L10 13.75ZM49.9984 26.25C49.9984 24.9859 50.1031 25.568 43.3539 12.0695C41.975 9.3125 38.0266 9.30703 36.6453 12.0695C29.8391 25.6836 30.0016 25.0258 30.0016 26.25H30C30 29.7016 34.4773 32.5 40 32.5C45.5227 32.5 50 29.7016 50 26.25H49.9984ZM34.375 25L40 13.75L45.625 25H34.375ZM41.25 35H27.5V11.9727C29.3367 11.1687 30.7156 9.51328 31.1242 7.5H41.25C41.9406 7.5 42.5 6.94063 42.5 6.25V3.75C42.5 3.05938 41.9406 2.5 41.25 2.5H29.9719C28.8313 0.990625 27.0383 0 25 0C22.9617 0 21.1687 0.990625 20.0281 2.5H8.75C8.05937 2.5 7.5 3.05938 7.5 3.75V6.25C7.5 6.94063 8.05937 7.5 8.75 7.5H18.8758C19.2844 9.5125 20.6625 11.1687 22.5 11.9727V35H8.75C8.05937 35 7.5 35.5594 7.5 36.25V38.75C7.5 39.4406 8.05937 40 8.75 40H41.25C41.9406 40 42.5 39.4406 42.5 38.75V36.25C42.5 35.5594 41.9406 35 41.25 35Z" />
            </symbol>
            <symbol id="org-icon" width="50" height="41" viewBox="0 0 50 41">
                <path d="M10 27.6127H2.5C1.11953 27.6127 0 28.7368 0 30.1229V37.6537C0 39.0398 1.11953 40.1639 2.5 40.1639H10C11.3805 40.1639 12.5 39.0398 12.5 37.6537V30.1229C12.5 28.7368 11.3805 27.6127 10 27.6127ZM8.125 21.3371H23.125V25.1025H26.875V21.3371H41.875V25.1025H45.625V20.5848C45.625 18.9241 44.2789 17.5717 42.6242 17.5717H26.875V12.5512H30C31.3805 12.5512 32.5 11.4271 32.5 10.041V2.51025C32.5 1.12412 31.3805 0 30 0H20C18.6195 0 17.5 1.12412 17.5 2.51025V10.041C17.5 11.4271 18.6195 12.5512 20 12.5512H23.125V17.5717H7.37578C5.72109 17.5717 4.375 18.9233 4.375 20.5848V25.1025H8.125V21.3371ZM28.75 27.6127H21.25C19.8695 27.6127 18.75 28.7368 18.75 30.1229V37.6537C18.75 39.0398 19.8695 40.1639 21.25 40.1639H28.75C30.1305 40.1639 31.25 39.0398 31.25 37.6537V30.1229C31.25 28.7368 30.1305 27.6127 28.75 27.6127ZM47.5 27.6127H40C38.6195 27.6127 37.5 28.7368 37.5 30.1229V37.6537C37.5 39.0398 38.6195 40.1639 40 40.1639H47.5C48.8805 40.1639 50 39.0398 50 37.6537V30.1229C50 28.7368 48.8805 27.6127 47.5 27.6127Z" />
            </symbol>
            <symbol id="employees-icon" width="50" height="36" viewBox="0 0 50 36">
                <path d="M7.5 15.5C10.2578 15.5 12.5 13.2578 12.5 10.5C12.5 7.74219 10.2578 5.5 7.5 5.5C4.74219 5.5 2.5 7.74219 2.5 10.5C2.5 13.2578 4.74219 15.5 7.5 15.5ZM42.5 15.5C45.2578 15.5 47.5 13.2578 47.5 10.5C47.5 7.74219 45.2578 5.5 42.5 5.5C39.7422 5.5 37.5 7.74219 37.5 10.5C37.5 13.2578 39.7422 15.5 42.5 15.5ZM45 18H40C38.625 18 37.3828 18.5547 36.4766 19.4531C39.625 21.1797 41.8594 24.2969 42.3438 28H47.5C48.8828 28 50 26.8828 50 25.5V23C50 20.2422 47.7578 18 45 18ZM25 18C29.8359 18 33.75 14.0859 33.75 9.25C33.75 4.41406 29.8359 0.5 25 0.5C20.1641 0.5 16.25 4.41406 16.25 9.25C16.25 14.0859 20.1641 18 25 18ZM31 20.5H30.3516C28.7266 21.2812 26.9219 21.75 25 21.75C23.0781 21.75 21.2812 21.2812 19.6484 20.5H19C14.0312 20.5 10 24.5313 10 29.5V31.75C10 33.8203 11.6797 35.5 13.75 35.5H36.25C38.3203 35.5 40 33.8203 40 31.75V29.5C40 24.5313 35.9688 20.5 31 20.5ZM13.5234 19.4531C12.6172 18.5547 11.375 18 10 18H5C2.24219 18 0 20.2422 0 23V25.5C0 26.8828 1.11719 28 2.5 28H7.64844C8.14062 24.2969 10.375 21.1797 13.5234 19.4531Z" />
            </symbol>
            <symbol id="linkedin-icon" width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M26.6667 0C27.5507 0 28.3986 0.351189 29.0237 0.976311C29.6488 1.60143 30 2.44928 30 3.33333V26.6667C30 27.5507 29.6488 28.3986 29.0237 29.0237C28.3986 29.6488 27.5507 30 26.6667 30H3.33333C2.44928 30 1.60143 29.6488 0.976311 29.0237C0.351189 28.3986 0 27.5507 0 26.6667V3.33333C0 2.44928 0.351189 1.60143 0.976311 0.976311C1.60143 0.351189 2.44928 0 3.33333 0H26.6667ZM25.8333 25.8333V17C25.8333 15.559 25.2609 14.177 24.2419 13.1581C23.223 12.1391 21.841 11.5667 20.4 11.5667C18.9833 11.5667 17.3333 12.4333 16.5333 13.7333V11.8833H11.8833V25.8333H16.5333V17.6167C16.5333 16.3333 17.5667 15.2833 18.85 15.2833C19.4688 15.2833 20.0623 15.5292 20.4999 15.9668C20.9375 16.4043 21.1833 16.9978 21.1833 17.6167V25.8333H25.8333ZM6.46667 9.26667C7.20927 9.26667 7.92146 8.97167 8.44657 8.44657C8.97167 7.92146 9.26667 7.20927 9.26667 6.46667C9.26667 4.91667 8.01667 3.65 6.46667 3.65C5.71964 3.65 5.00321 3.94675 4.47498 4.47498C3.94675 5.00321 3.65 5.71964 3.65 6.46667C3.65 8.01667 4.91667 9.26667 6.46667 9.26667ZM8.78333 25.8333V11.8833H4.16667V25.8333H8.78333Z" fill="#004D86" />
            </symbol>
            <symbol id="item-list-icon" width="9" height="18" viewBox="0 0 9 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0.666992 17.3334L9.00033 9.00008L0.666992 0.666748V17.3334Z" fill="#004D86" />
            </symbol>

            <symbol id="admin-inmuebles-icon" viewBox="0 0 30 42" xmlns="http://www.w3.org/2000/svg">
                <path d="M35.5321 69.757C32.982 72.3451 32.0546 72.4717 28.5828 70.688C26.1523 72.5648 24.4827 72.0416 23.6751 69.582C22.4449 69.582 21.2988 69.8129 20.3322 69.5299C18.8178 69.0867 18.2495 67.869 18.4439 66.3981C15.1441 67.0088 13.6484 66.0238 13.2838 62.9814C11.6311 63.661 10.1148 63.4729 9.06786 62.0783C7.3067 59.7323 9.63996 58.3935 10.786 56.809C10.1148 55.3828 7.39457 54.4686 9.70727 52.359C10.1303 52.7471 10.5304 53.1593 10.9057 53.5934C11.6535 54.5505 12.3116 55.1128 13.884 54.7572C16.0359 54.273 17.468 56.2467 17.1707 58.8758C20.4537 58.995 21.3642 59.7528 21.6335 62.5848C24.4977 62.1025 26.1205 63.2923 26.143 65.8953C28.9006 66.1392 28.8688 66.1504 29.9027 69.0774C30.0299 69.4349 30.7497 69.8613 31.1647 69.8352C32.0116 69.7812 32.8474 69.4405 33.6737 69.2189V68.5821C32.0808 67.465 30.4449 66.3981 28.9231 65.2064C28.4818 64.8601 28.3622 64.16 28.1042 63.6219C28.7417 63.6722 29.5195 63.5232 29.9906 63.8081C32.2977 65.199 34.53 66.696 36.7735 68.1725C37.8355 68.8726 38.8301 68.9843 39.606 67.8727C40.337 66.83 39.7929 66.0871 38.8245 65.4522C36.5267 63.944 34.2084 62.4563 31.9929 60.8513C31.3891 60.4138 30.6001 59.2054 30.7758 59.0043C31.6602 57.9914 32.4847 58.9354 33.2344 59.4195C35.9472 61.1697 38.6375 62.9572 41.3297 64.7298C42.3562 65.4075 43.4536 65.9158 44.366 64.7186C45.2484 63.5623 44.4912 62.758 43.4181 62.0616C40.408 60.1103 37.4354 58.1198 34.444 56.1443C34.0944 55.9134 33.6176 55.7459 33.4307 55.433C33.1689 54.9973 33.1259 54.4518 32.9876 53.9547C33.526 53.9379 34.1916 53.7219 34.5786 53.9379C35.9397 54.6938 37.2073 55.595 38.5048 56.4478C40.6997 57.8927 42.904 59.3282 45.0802 60.7992C46.3384 61.6482 47.5929 61.8512 48.653 60.6558C49.7916 59.3711 48.9895 58.4326 47.8453 57.5147C42.6628 53.3514 37.4933 49.175 32.3837 44.9335C30.4131 43.2987 26.9319 44.1403 26.4982 46.6093C25.9915 49.5009 23.6414 51.2362 20.8781 51.4075C18.3691 51.5639 17.3913 50.3574 18.2607 48.2143C18.4997 47.6372 18.6874 47.0403 18.8216 46.4305C19.2142 44.5909 19.5694 42.742 19.9433 40.7851H16.0789C16.479 39.0423 17.0903 38.0536 19.2179 38.2305C22.127 38.4707 25.0137 38.3832 27.8293 37.2195C30.2953 36.201 32.9857 36.4616 35.5901 37.1264C37.1811 37.5341 38.7871 38.1635 40.3949 38.184C42.7338 38.2156 43.7808 39.2434 44.652 41.083C46.488 44.9633 48.5782 48.7431 50.5338 52.575C50.7843 53.0665 51.1844 53.8374 50.9676 54.1278C49.7224 55.785 50.5544 57.2261 51.1283 58.8162C51.7864 60.6372 50.4048 62.6593 48.3464 63.0987C47.333 63.3128 46.7628 63.6275 46.5908 64.6683C46.3272 66.2696 45.1344 67.0516 43.4125 67.2359C42.9208 67.2881 42.2645 67.4221 42.0084 67.7368C39.3835 70.9934 39.2788 71.0455 35.5321 69.757Z" />
                <path d="M4.99207 53.9324C3.30943 53.1317 1.70344 52.4428 0.213362 51.5919C-0.055861 51.4373 -0.0633394 50.5064 0.151665 50.0837C2.9299 44.6114 5.76983 39.1652 8.60041 33.7135C8.70511 33.5105 8.78737 33.2275 8.96498 33.1363C11.0982 32.0582 12.4387 33.8922 14.0971 34.462C14.5252 34.6091 14.9627 35.8845 14.7271 36.3593C11.9769 41.9042 9.11829 47.4006 6.23349 52.8897C6.02596 53.2807 5.49126 53.5246 4.99207 53.9324Z" />
                <path d="M44.4111 35.3184C45.202 34.8213 45.9274 34.2013 46.7874 33.8661C48.0082 33.4025 49.1076 32.1662 50.6463 33.058C50.9192 33.2163 51.0482 33.6166 51.2071 33.9127C53.8994 39.1075 56.5467 44.3265 59.3006 49.4935C60.0728 50.9421 59.8279 51.6719 58.2107 52.3832C53.26 54.5635 54.1499 54.1036 52.1438 50.3742C49.7769 45.9725 47.5595 41.5038 45.2786 37.0649C45.0431 36.6106 44.8224 36.1489 44.4111 35.3184Z" />
                <path d="M10.7051 15.4141C13.115 13.3865 15.5174 11.3588 17.9348 9.33488C21.3089 6.5221 24.6922 3.71676 28.0849 0.918872C29.5656 -0.308152 30.9809 -0.304428 32.4579 0.918872C34.2546 2.40843 36.0532 3.9073 38.035 5.55326V1.99322C38.035 0.0791334 38.035 0.0772714 39.9513 0.0772714C40.9945 0.0772714 42.0378 0.0772714 43.081 0.0772714C44.0569 0.0903051 44.2533 0.28581 44.2551 1.25775C44.2551 4.1717 44.2383 7.08751 44.2832 10.0089C44.3122 10.4419 44.503 10.8484 44.8179 11.1484C46.4613 12.6026 48.1551 13.9991 49.8322 15.416V15.9355C49.3554 16.5127 48.8974 17.0992 48.3982 17.6634C47.7719 18.3858 47.4634 18.4082 46.7305 17.7993C43.8849 15.4408 41.0407 13.0762 38.1976 10.7053L30.2724 4.12142C28.7299 5.39872 27.2006 6.66298 25.675 7.93097C21.7401 11.1981 17.8058 14.467 13.8722 17.7379C13.0514 18.4212 12.7766 18.4063 12.0811 17.5963C11.61 17.0527 11.1631 16.4792 10.7051 15.9336V15.4141Z" />
                <path d="M30.2689 6.27197L39.5477 13.8836C40.9555 15.0399 42.3783 16.1794 43.7543 17.3692C44.0375 17.6273 44.2102 17.9839 44.2367 18.3653C44.2722 21.9421 44.2629 25.5208 44.2554 29.0976C44.2554 30.401 43.6515 30.9986 42.339 31.0024C39.3888 31.0024 36.4386 31.0024 33.3855 31.0024V21.7485H27.1485V30.9931C23.9515 30.9931 20.8554 31.0173 17.7612 30.9782C16.8807 30.967 16.2955 30.2874 16.2899 29.3527C16.2699 25.6288 16.2699 21.9049 16.2899 18.181C16.2957 17.9316 16.3982 17.694 16.5759 17.5181C21.124 13.7682 25.6884 10.0195 30.2689 6.27197Z" />
            </symbol>

            <symbol id="promocion-icon" viewBox="0 0 40 50" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 23.9696L1.76652 23.0687C1.77723 22.6879 1.75735 22.0761 1.81547 21.4735C1.94547 20.0878 2.97632 18.9361 4.31154 18.8413C7.08903 18.641 9.87111 18.5263 12.7236 18.3718L12.8918 19.577C13.528 19.424 14.1567 19.2879 14.7746 19.1182C18.5814 18.0292 22.1267 16.411 25.1122 13.7008C25.571 13.2879 25.8279 12.6562 26.2638 12.2157C26.585 11.8899 27.053 11.5076 27.443 11.5198C27.8331 11.5321 28.2827 11.9465 28.5595 12.3029C28.7538 12.5507 28.7385 13.0003 28.7538 13.3582C28.8792 15.4704 29.0031 17.5811 29.0903 19.6948C29.1117 20.2056 29.2707 20.4687 29.7372 20.7103C32.8833 22.33 33.0714 26.5697 30.0982 28.4937C29.7066 28.7461 29.5965 28.9847 29.6241 29.4313C29.7617 31.626 29.8749 33.8239 29.9804 36.0202C29.9972 36.3811 30.0446 36.8308 29.8688 37.0908C29.6072 37.4701 29.1882 37.8785 28.7767 37.9595C28.4494 38.0238 27.9799 37.6812 27.6633 37.4104C26.9597 36.8063 26.3908 36.014 25.6306 35.5109C21.9599 33.0851 17.8671 31.9564 13.5311 31.4349C13.5173 31.8448 13.5051 32.2271 13.4898 32.6737L10.8026 32.8267C11.4526 36.4347 12.0888 39.96 12.7358 43.5512C11.9711 43.7944 11.2354 44.01 10.512 44.2517C9.98735 44.4245 9.93229 44.0422 9.80688 43.6873C8.62767 40.3394 7.44693 37.0128 6.24171 33.6786C6.15912 33.4522 5.88841 33.1631 5.6804 33.1387C3.06503 32.8328 2.40278 32.169 2.16265 29.5154C2.15348 29.4083 2.12442 29.3013 1.98982 29.3732L0.246243 28.5335L0 23.9696ZM5.3531 29.8687L10.1984 29.6072L9.77782 21.7978L4.9325 22.0593L5.3531 29.8687Z" />
                <path d="M59.6486 15.2946C59.4024 16.824 58.9864 19.288 58.3455 20.3678C54.4561 27.001 46.789 29.5369 40.145 25.9992C39.5684 25.6933 39.1799 25.6933 38.6156 26.0727C37.2689 26.9694 35.6517 27.3685 34.0425 27.2014C33.7641 27.1754 33.5056 26.9154 33.238 26.7624C33.3922 26.4999 33.5639 26.248 33.7519 26.0084C34.4478 25.2253 35.1712 24.4683 35.8687 23.6867C36.2785 23.2279 36.1302 22.821 35.7677 22.3683C33.5775 19.6321 32.6293 16.4845 32.7899 12.956C33.0269 7.68094 36.4942 2.76068 41.3181 0.919215C49.2208 -2.09687 57.5915 2.55573 59.3733 10.9524C59.462 11.3883 59.8903 13.3858 59.6486 15.2946ZM46.3852 2.86468C40.3913 2.86468 35.5261 7.8293 35.5261 13.9548C35.5261 20.0802 40.3851 25.0449 46.3852 25.0449C52.3853 25.0449 57.2443 20.0802 57.2443 13.9548C57.2443 7.8293 52.3776 2.86468 46.3852 2.86468Z" />
                <path d="M37.5649 13.4669C38.6004 12.5936 39.6328 11.7141 40.6713 10.8454C42.1212 9.63102 43.5747 8.4207 45.0317 7.21447C45.668 6.68528 46.2752 6.68834 46.9099 7.21447L49.305 9.21347V7.67943C49.305 6.85352 49.305 6.85352 50.1279 6.85352C50.576 6.85352 51.0242 6.85352 51.4723 6.85352C51.8914 6.85352 51.977 6.94376 51.977 7.36283C51.977 8.62004 51.977 9.87726 51.9892 11.1329C52.0013 11.3201 52.0832 11.4958 52.2187 11.6254C52.9253 12.2525 53.6533 12.849 54.3721 13.4608V13.6856C54.1672 13.9334 53.9684 14.1873 53.7604 14.4304C53.4912 14.7363 53.3581 14.7516 53.0446 14.4886C51.821 13.4689 50.5974 12.4493 49.3739 11.4297L45.9708 8.5971L43.9963 10.2474L38.9262 14.4702C38.5729 14.7639 38.4551 14.7578 38.1614 14.409C37.9595 14.1735 37.7668 13.9303 37.5695 13.6917L37.5649 13.4669Z" />
                <path d="M45.9692 9.52405L49.9549 12.8078C50.5591 13.3064 51.1709 13.7973 51.7612 14.3112C51.8831 14.4226 51.9575 14.5764 51.9692 14.741C51.9845 16.2827 51.9799 17.8259 51.9692 19.3692C51.9692 19.932 51.7108 20.1889 51.1464 20.1905C49.8785 20.1905 48.6121 20.1905 47.2998 20.1905V16.1986H44.6294V20.1889C43.2529 20.1889 41.9253 20.1997 40.5962 20.1889C40.2184 20.1889 39.9661 19.8907 39.9645 19.4869C39.9554 17.8825 39.9645 16.2751 39.9645 14.6707C39.9683 14.5631 40.0125 14.461 40.0884 14.3847C42.042 12.7614 44.0023 11.1412 45.9692 9.52405Z" />
            </symbol>

            <symbol id="editorial-icon" width="50" height="40" viewBox="0 0 80 40" xmlns="http://www.w3.org/2000/svg">
                <path d="M26.4957 30.6287L56.5188 23.5777L56.3911 22.2002C57.2012 22.7439 57.9435 23.1931 58.6259 23.7195C59.0688 24.0615 58.8655 24.7266 58.2934 24.8842C57.5353 25.0938 56.7678 25.2671 56.0018 25.4484C46.2831 27.7599 36.5644 30.0756 26.8456 32.3954C26.4815 32.4821 26.2641 32.4506 25.9977 32.137C19.5928 24.5879 13.1805 17.0467 6.76089 9.51331C6.19353 8.84508 6.02017 8.01925 5.89093 7.19342C5.67344 5.84278 5.7554 4.52365 6.46145 3.29436C6.53994 3.13988 6.65743 3.00859 6.80228 2.91349C6.94714 2.8184 7.11433 2.7628 7.28728 2.75222C15.0365 1.85862 22.7905 0.968169 30.5382 0.0367452C31.4801 -0.0939237 32.4371 0.12654 33.2269 0.656118C41.7899 6.03768 50.365 11.4003 58.9521 16.7441C59.0231 16.7882 59.0908 16.8355 59.1649 16.8764C59.5069 17.064 59.7874 17.3004 59.7086 17.7417C59.633 18.1546 59.3115 18.2744 58.9474 18.3611C57.6614 18.6652 56.3785 18.9915 55.0941 19.3067L35.334 24.0993C33.2048 24.6162 31.0788 25.1442 28.9417 25.6359C28.4531 25.7543 28.0238 26.0454 27.7329 26.4555C26.9055 27.5019 26.4374 28.6729 26.4453 30.0172C26.4469 30.1969 26.4768 30.3766 26.4957 30.6287Z" />
                <path d="M53.7909 33.776C53.0029 34.5136 52.2275 35.2543 51.4427 35.9824C47.365 39.8143 43.2889 43.6492 39.2144 47.4873C39.0428 47.6425 38.9155 47.8405 38.8456 48.061C38.5651 49.1091 38.3192 50.165 38.0576 51.213L38.1947 51.2903C38.3176 51.1768 38.4453 51.0665 38.5651 50.9483C43.7701 45.7789 48.9778 40.6107 54.1881 35.4434C54.6719 34.9706 55.1794 34.5294 54.8185 33.6405C55.2708 33.7981 55.5529 33.8848 55.8303 33.9904C56.4828 34.2394 56.6073 34.7784 56.1219 35.2811C55.1368 36.3087 54.144 37.3299 53.1542 38.3528L39.1797 52.8032C38.3097 53.7016 37.5706 53.7804 36.5005 53.0822L14.2062 38.4568C9.83538 35.5916 5.46351 32.7306 1.0906 29.8738C0.841016 29.7219 0.629192 29.5153 0.471117 29.2696C0.313042 29.0239 0.212845 28.7455 0.17809 28.4554C-0.0362483 27.1174 -0.105593 25.7856 0.247434 24.4681C0.339296 24.1955 0.51957 23.9614 0.759639 23.803C1.26239 23.4736 1.82187 23.2325 2.33565 22.9189C2.62406 22.7424 2.80846 22.7613 3.08111 22.9772C7.70408 26.6314 12.3349 30.2799 16.9737 33.9226C21.6597 37.6084 26.3457 41.2941 31.0317 44.9799C32.3965 46.0532 33.8386 46.1383 35.3185 45.2116C41.322 41.4544 47.323 37.6929 53.3213 33.9273C53.4552 33.8438 53.5971 33.7697 53.7358 33.6909L53.7909 33.776Z" />
                <path d="M3.73188 17.6393C3.69248 18.0049 3.67672 18.3201 3.6184 18.6274C3.58715 18.7556 3.59749 18.8903 3.64792 19.0121C3.69836 19.134 3.78628 19.2366 3.89894 19.3051C9.38976 23.5919 14.8769 27.8839 20.3604 32.1812C24.5547 35.4635 28.7453 38.7495 32.9322 42.0391C33.2364 42.2771 33.4381 42.2755 33.7581 42.0817C40.8176 37.8044 47.8797 33.5339 54.9444 29.2703C55.5023 28.933 55.6379 28.5421 55.4881 27.721C55.4708 27.6249 55.4424 27.5303 55.3999 27.3617L56.7773 27.0339C56.9885 27.8788 56.9885 28.7627 56.7773 29.6075C56.7505 29.7226 56.5803 29.8219 56.4621 29.8991C49.1158 34.5095 41.769 39.1172 34.4216 43.7223C33.539 44.2755 32.8897 44.2314 32.0717 43.5868C22.0168 35.6752 11.9623 27.7625 1.90843 19.8489C1.56644 19.5809 1.08733 19.376 1.1945 18.8024C1.30167 18.2287 1.8249 18.2271 2.23624 18.0932C2.7122 17.9419 3.19288 17.8016 3.73188 17.6393Z" />
                <path d="M5.55094 10.7804C9.4437 15.3613 13.3312 19.9318 17.2134 24.4917L17.1378 24.5752C16.0367 23.8072 14.9335 23.0386 13.8282 22.2695C9.86292 19.4979 5.90292 16.7235 1.94818 13.9466C1.79846 13.841 1.64401 13.7401 1.49901 13.6314C0.977355 13.2279 1.02621 12.6133 1.61879 12.3706C2.9127 11.8221 4.22079 11.3115 5.55094 10.7804Z" />
                <path d="M29.8169 33.4766L48.748 28.9677L48.7826 29.0559C47.9395 29.5287 47.0995 29.9873 46.261 30.4491C42.767 32.3608 39.2683 34.2615 35.7837 36.1889C34.9673 36.6397 34.2502 36.605 33.4985 36.0581C32.318 35.2024 31.114 34.3844 29.8169 33.4766Z" />
            </symbol>

            <symbol id="shop-car-icon" viewBox="0 0 26 26" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.25 20.5C20.913 20.5 21.5489 20.7634 22.0178 21.2322C22.4866 21.7011 22.75 22.337 22.75 23C22.75 23.663 22.4866 24.2989 22.0178 24.7678C21.5489 25.2366 20.913 25.5 20.25 25.5C18.8625 25.5 17.75 24.375 17.75 23C17.75 21.6125 18.8625 20.5 20.25 20.5ZM0.25 0.5H4.3375L5.5125 3H24C24.3315 3 24.6495 3.1317 24.8839 3.36612C25.1183 3.60054 25.25 3.91848 25.25 4.25C25.25 4.4625 25.1875 4.675 25.1 4.875L20.625 12.9625C20.2 13.725 19.375 14.25 18.4375 14.25H9.125L8 16.2875L7.9625 16.4375C7.9625 16.5204 7.99542 16.5999 8.05403 16.6585C8.11263 16.7171 8.19212 16.75 8.275 16.75H22.75V19.25H7.75C6.3625 19.25 5.25 18.125 5.25 16.75C5.25 16.3125 5.3625 15.9 5.55 15.55L7.25 12.4875L2.75 3H0.25V0.5ZM7.75 20.5C8.41304 20.5 9.04893 20.7634 9.51777 21.2322C9.98661 21.7011 10.25 22.337 10.25 23C10.25 23.663 9.98661 24.2989 9.51777 24.7678C9.04893 25.2366 8.41304 25.5 7.75 25.5C6.3625 25.5 5.25 24.375 5.25 23C5.25 21.6125 6.3625 20.5 7.75 20.5ZM19 11.75L22.475 5.5H6.675L9.625 11.75H19Z" />
            </symbol>

            <symbol id="inmuebles-icon" width="50" height="50" viewBox="0 0 60 72" xmlns="http://www.w3.org/2000/svg">
                <path d="M35.5321 69.757C32.982 72.3451 32.0546 72.4717 28.5828 70.688C26.1523 72.5648 24.4827 72.0416 23.6751 69.582C22.4449 69.582 21.2988 69.8129 20.3322 69.5299C18.8178 69.0867 18.2495 67.869 18.4439 66.3981C15.1441 67.0088 13.6484 66.0238 13.2838 62.9814C11.6311 63.661 10.1148 63.4729 9.06786 62.0783C7.3067 59.7323 9.63996 58.3935 10.786 56.809C10.1148 55.3828 7.39457 54.4686 9.70727 52.359C10.1303 52.7471 10.5304 53.1593 10.9057 53.5934C11.6535 54.5505 12.3116 55.1128 13.884 54.7572C16.0359 54.273 17.468 56.2467 17.1707 58.8758C20.4537 58.995 21.3642 59.7528 21.6335 62.5848C24.4977 62.1025 26.1205 63.2923 26.143 65.8953C28.9006 66.1392 28.8688 66.1504 29.9027 69.0774C30.0299 69.4349 30.7497 69.8613 31.1647 69.8352C32.0116 69.7812 32.8474 69.4405 33.6737 69.2189V68.5821C32.0808 67.465 30.4449 66.3981 28.9231 65.2064C28.4818 64.8601 28.3622 64.16 28.1042 63.6219C28.7417 63.6722 29.5195 63.5232 29.9906 63.8081C32.2977 65.199 34.53 66.696 36.7735 68.1725C37.8355 68.8726 38.8301 68.9843 39.606 67.8727C40.337 66.83 39.7929 66.0871 38.8245 65.4522C36.5267 63.944 34.2084 62.4563 31.9929 60.8513C31.3891 60.4138 30.6001 59.2054 30.7758 59.0043C31.6602 57.9914 32.4847 58.9354 33.2344 59.4195C35.9472 61.1697 38.6375 62.9572 41.3297 64.7298C42.3562 65.4075 43.4536 65.9158 44.366 64.7186C45.2484 63.5623 44.4912 62.758 43.4181 62.0616C40.408 60.1103 37.4354 58.1198 34.444 56.1443C34.0944 55.9134 33.6176 55.7459 33.4307 55.433C33.1689 54.9973 33.1259 54.4518 32.9876 53.9547C33.526 53.9379 34.1916 53.7219 34.5786 53.9379C35.9397 54.6938 37.2073 55.595 38.5048 56.4478C40.6997 57.8927 42.904 59.3282 45.0802 60.7992C46.3384 61.6482 47.5929 61.8512 48.653 60.6558C49.7916 59.3711 48.9895 58.4326 47.8453 57.5147C42.6628 53.3514 37.4933 49.175 32.3837 44.9335C30.4131 43.2987 26.9319 44.1403 26.4982 46.6093C25.9915 49.5009 23.6414 51.2362 20.8781 51.4075C18.3691 51.5639 17.3913 50.3574 18.2607 48.2143C18.4997 47.6372 18.6874 47.0403 18.8216 46.4305C19.2142 44.5909 19.5694 42.742 19.9433 40.7851H16.0789C16.479 39.0423 17.0903 38.0536 19.2179 38.2305C22.127 38.4707 25.0137 38.3832 27.8293 37.2195C30.2953 36.201 32.9857 36.4616 35.5901 37.1264C37.1811 37.5341 38.7871 38.1635 40.3949 38.184C42.7338 38.2156 43.7808 39.2434 44.652 41.083C46.488 44.9633 48.5782 48.7431 50.5338 52.575C50.7843 53.0665 51.1844 53.8374 50.9676 54.1278C49.7224 55.785 50.5544 57.2261 51.1283 58.8162C51.7864 60.6372 50.4048 62.6593 48.3464 63.0987C47.333 63.3128 46.7628 63.6275 46.5908 64.6683C46.3272 66.2696 45.1344 67.0516 43.4125 67.2359C42.9208 67.2881 42.2645 67.4221 42.0084 67.7368C39.3835 70.9934 39.2788 71.0455 35.5321 69.757Z" />
                <path d="M4.99207 53.9324C3.30943 53.1317 1.70344 52.4428 0.213362 51.5919C-0.055861 51.4373 -0.0633394 50.5064 0.151665 50.0837C2.9299 44.6114 5.76983 39.1652 8.60041 33.7135C8.70511 33.5105 8.78737 33.2275 8.96498 33.1363C11.0982 32.0582 12.4387 33.8922 14.0971 34.462C14.5252 34.6091 14.9627 35.8845 14.7271 36.3593C11.9769 41.9042 9.11829 47.4006 6.23349 52.8897C6.02596 53.2807 5.49126 53.5246 4.99207 53.9324Z" />
                <path d="M44.4111 35.3184C45.202 34.8213 45.9274 34.2013 46.7874 33.8661C48.0082 33.4025 49.1076 32.1662 50.6463 33.058C50.9192 33.2163 51.0482 33.6166 51.2071 33.9127C53.8994 39.1075 56.5467 44.3265 59.3006 49.4935C60.0728 50.9421 59.8279 51.6719 58.2107 52.3832C53.26 54.5635 54.1499 54.1036 52.1438 50.3742C49.7769 45.9725 47.5595 41.5038 45.2786 37.0649C45.0431 36.6106 44.8224 36.1489 44.4111 35.3184Z" />
                <path d="M10.7051 15.4141C13.115 13.3865 15.5174 11.3588 17.9348 9.33488C21.3089 6.5221 24.6922 3.71676 28.0849 0.918872C29.5656 -0.308152 30.9809 -0.304428 32.4579 0.918872C34.2546 2.40843 36.0532 3.9073 38.035 5.55326V1.99322C38.035 0.0791334 38.035 0.0772714 39.9513 0.0772714C40.9945 0.0772714 42.0378 0.0772714 43.081 0.0772714C44.0569 0.0903051 44.2533 0.28581 44.2551 1.25775C44.2551 4.1717 44.2383 7.08751 44.2832 10.0089C44.3122 10.4419 44.503 10.8484 44.8179 11.1484C46.4613 12.6026 48.1551 13.9991 49.8322 15.416V15.9355C49.3554 16.5127 48.8974 17.0992 48.3982 17.6634C47.7719 18.3858 47.4634 18.4082 46.7305 17.7993C43.8849 15.4408 41.0407 13.0762 38.1976 10.7053L30.2724 4.12142C28.7299 5.39872 27.2006 6.66298 25.675 7.93097C21.7401 11.1981 17.8058 14.467 13.8722 17.7379C13.0514 18.4212 12.7766 18.4063 12.0811 17.5963C11.61 17.0527 11.1631 16.4792 10.7051 15.9336V15.4141Z" />
                <path d="M30.2689 6.27197L39.5477 13.8836C40.9555 15.0399 42.3783 16.1794 43.7543 17.3692C44.0375 17.6273 44.2102 17.9839 44.2367 18.3653C44.2722 21.9421 44.2629 25.5208 44.2554 29.0976C44.2554 30.401 43.6515 30.9986 42.339 31.0024C39.3888 31.0024 36.4386 31.0024 33.3855 31.0024V21.7485H27.1485V30.9931C23.9515 30.9931 20.8554 31.0173 17.7612 30.9782C16.8807 30.967 16.2955 30.2874 16.2899 29.3527C16.2699 25.6288 16.2699 21.9049 16.2899 18.181C16.2957 17.9316 16.3982 17.694 16.5759 17.5181C21.124 13.7682 25.6884 10.0195 30.2689 6.27197Z" />
            </symbol>

            <symbol id="inmobiliaria-icon" width="50" height="50" viewBox="0 0 65 50" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_453_371)">
                    <path d="M0 23.9696L1.76652 23.0687C1.77723 22.6879 1.75735 22.0761 1.81547 21.4735C1.94547 20.0878 2.97632 18.9361 4.31154 18.8413C7.08903 18.641 9.87111 18.5263 12.7236 18.3718L12.8918 19.577C13.528 19.424 14.1567 19.2879 14.7746 19.1182C18.5814 18.0292 22.1267 16.411 25.1122 13.7008C25.571 13.2879 25.8279 12.6562 26.2638 12.2157C26.585 11.8899 27.053 11.5076 27.443 11.5198C27.8331 11.5321 28.2827 11.9465 28.5595 12.3029C28.7538 12.5507 28.7385 13.0003 28.7538 13.3582C28.8792 15.4704 29.0031 17.5811 29.0903 19.6948C29.1117 20.2056 29.2707 20.4687 29.7372 20.7103C32.8833 22.33 33.0714 26.5697 30.0982 28.4937C29.7066 28.7461 29.5965 28.9847 29.6241 29.4313C29.7617 31.626 29.8749 33.8239 29.9804 36.0202C29.9972 36.3811 30.0446 36.8308 29.8688 37.0908C29.6072 37.4701 29.1882 37.8785 28.7767 37.9595C28.4494 38.0238 27.9799 37.6812 27.6633 37.4104C26.9597 36.8063 26.3908 36.014 25.6306 35.5109C21.9599 33.0851 17.8671 31.9564 13.5311 31.4349C13.5173 31.8448 13.5051 32.2271 13.4898 32.6737L10.8026 32.8267C11.4526 36.4347 12.0888 39.96 12.7358 43.5512C11.9711 43.7944 11.2354 44.01 10.512 44.2517C9.98735 44.4245 9.93229 44.0422 9.80688 43.6873C8.62767 40.3394 7.44693 37.0128 6.24171 33.6786C6.15912 33.4522 5.88841 33.1631 5.6804 33.1387C3.06503 32.8328 2.40278 32.169 2.16265 29.5154C2.15348 29.4083 2.12442 29.3013 1.98982 29.3732L0.246243 28.5335L0 23.9696ZM5.3531 29.8687L10.1984 29.6072L9.77782 21.7978L4.9325 22.0593L5.3531 29.8687Z" />
                    <path d="M59.6486 15.2946C59.4024 16.824 58.9864 19.288 58.3455 20.3678C54.4561 27.001 46.789 29.5369 40.145 25.9992C39.5684 25.6933 39.1799 25.6933 38.6156 26.0727C37.2689 26.9694 35.6517 27.3685 34.0425 27.2014C33.7641 27.1754 33.5056 26.9154 33.238 26.7624C33.3922 26.4999 33.5639 26.248 33.7519 26.0084C34.4478 25.2253 35.1712 24.4683 35.8687 23.6867C36.2785 23.2279 36.1302 22.821 35.7677 22.3683C33.5775 19.6321 32.6293 16.4845 32.7899 12.956C33.0269 7.68094 36.4942 2.76068 41.3181 0.919215C49.2208 -2.09687 57.5915 2.55573 59.3733 10.9524C59.462 11.3883 59.8903 13.3858 59.6486 15.2946ZM46.3852 2.86468C40.3913 2.86468 35.5261 7.8293 35.5261 13.9548C35.5261 20.0802 40.3851 25.0449 46.3852 25.0449C52.3853 25.0449 57.2443 20.0802 57.2443 13.9548C57.2443 7.8293 52.3776 2.86468 46.3852 2.86468Z" />
                    <path d="M37.5649 13.4669C38.6004 12.5936 39.6328 11.7141 40.6713 10.8454C42.1212 9.63102 43.5747 8.4207 45.0317 7.21447C45.668 6.68528 46.2752 6.68834 46.9099 7.21447L49.305 9.21347V7.67943C49.305 6.85352 49.305 6.85352 50.1279 6.85352C50.576 6.85352 51.0242 6.85352 51.4723 6.85352C51.8914 6.85352 51.977 6.94376 51.977 7.36283C51.977 8.62004 51.977 9.87726 51.9892 11.1329C52.0013 11.3201 52.0832 11.4958 52.2187 11.6254C52.9253 12.2525 53.6533 12.849 54.3721 13.4608V13.6856C54.1672 13.9334 53.9684 14.1873 53.7604 14.4304C53.4912 14.7363 53.3581 14.7516 53.0446 14.4886C51.821 13.4689 50.5974 12.4493 49.3739 11.4297L45.9708 8.5971L43.9963 10.2474L38.9262 14.4702C38.5729 14.7639 38.4551 14.7578 38.1614 14.409C37.9595 14.1735 37.7668 13.9303 37.5695 13.6917L37.5649 13.4669Z" />
                    <path d="M45.9692 9.52405L49.9549 12.8078C50.5591 13.3064 51.1709 13.7973 51.7612 14.3112C51.8831 14.4226 51.9575 14.5764 51.9692 14.741C51.9845 16.2827 51.9799 17.8259 51.9692 19.3692C51.9692 19.932 51.7108 20.1889 51.1464 20.1905C49.8785 20.1905 48.6121 20.1905 47.2998 20.1905V16.1986H44.6294V20.1889C43.2529 20.1889 41.9253 20.1997 40.5962 20.1889C40.2184 20.1889 39.9661 19.8907 39.9645 19.4869C39.9554 17.8825 39.9645 16.2751 39.9645 14.6707C39.9683 14.5631 40.0125 14.461 40.0884 14.3847C42.042 12.7614 44.0023 11.1412 45.9692 9.52405Z" />
                </g>
                <defs>
                    <clipPath id="clip0_453_371">
                        <rect width="59.7222" height="44.2823" />
                    </clipPath>
                </defs>
            </symbol>


            <symbol id="subasta-icon" width="40" height="50" viewBox="0 0 60 59" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_453_377)">
                    <path d="M54.8428 58.7433C55.5603 58.4314 56.3614 58.2416 56.9822 57.7904C59.1596 56.1886 59.3342 53.0375 57.415 51.0716C56.1282 49.7351 54.628 48.6315 52.9786 47.8081C50.4254 46.5492 48.2423 44.7847 46.2358 42.8034C44.4874 41.0777 42.8188 39.2726 41.1995 37.5953C41.5108 36.6269 41.8848 35.7825 42.0329 34.9071C42.3347 33.1039 40.9964 32.3892 39.6315 32.6933C38.9581 32.8741 38.2947 33.0914 37.6439 33.3441C33.7308 29.424 29.776 25.4587 25.7794 21.4482C26.5577 20.6735 27.3797 19.8639 28.1997 19.0485C28.7142 18.5372 29.2115 18.0104 29.745 17.5204C29.818 17.4665 29.9019 17.4298 29.9906 17.413C30.0792 17.3963 30.1704 17.3999 30.2575 17.4236C30.9561 17.6831 31.6053 17.6327 32.1862 17.1679C32.4976 16.9193 32.781 16.636 33.031 16.3235C33.3139 15.9836 33.4585 15.546 33.4348 15.1007C33.4111 14.6554 33.2211 14.2363 32.9038 13.9296C29.8905 10.9004 26.869 7.87836 23.8393 4.86341C23.6705 4.6923 23.4703 4.55688 23.2501 4.46493C23.0299 4.37297 22.794 4.32628 22.5561 4.32754C22.3182 4.3288 22.0828 4.37798 21.8636 4.47227C21.6443 4.56655 21.4455 4.70408 21.2784 4.87696C20.9481 5.18877 20.6503 5.53473 20.39 5.90928C20.0616 6.40704 20.1508 6.95322 20.3236 7.50133C20.3445 7.58905 20.3456 7.68048 20.3269 7.76871C20.3081 7.85695 20.27 7.93969 20.2154 8.01071C16.158 12.0961 12.0874 16.1705 8.00343 20.2339C7.93153 20.2901 7.84793 20.3288 7.75907 20.347C7.67021 20.3651 7.57846 20.3622 7.49088 20.3384C6.63853 19.9782 5.97222 20.2358 5.31919 20.8285C4.60542 21.487 4.08528 22.1997 4.47634 23.2223C4.59549 23.5206 4.77314 23.7908 4.99838 24.0164C6.52843 25.5562 8.07936 27.0727 9.61891 28.6028C11.0483 30.0263 12.4531 31.4731 13.9053 32.8637C14.7102 33.6385 15.6765 33.6017 16.5136 32.8637C17.609 31.8953 17.8216 31.1206 17.309 30.0147L21.5765 25.8041C21.6448 25.868 21.7777 25.9978 21.9068 26.1179C25.6161 29.8262 29.3286 33.5332 33.0443 37.239C33.3613 37.5547 33.3423 37.7697 33.1942 38.159C32.9131 38.819 32.7301 39.5181 32.6513 40.2333C32.5735 41.4534 33.5587 42.2901 34.7661 42.0539C35.664 41.8757 36.5315 41.5425 37.5737 41.2288C38.838 42.416 40.2674 43.7273 41.6627 45.0753C44.3469 47.6258 46.6074 50.6039 48.3562 53.8935C49.0491 55.2144 50.1539 56.332 51.1448 57.4785C51.7922 58.232 52.7337 58.538 53.6924 58.7433H54.8428Z" />
                    <path d="M28.1673 58.7434C28.6381 58.5497 29.1525 58.4355 29.5702 58.1624C30.2972 57.6937 30.7623 57.0003 30.6484 56.0958C30.5174 55.0499 29.8283 54.3992 28.8716 54.0622C28.4374 53.9159 27.9829 53.842 27.5257 53.8433C19.435 53.8317 11.345 53.8317 3.25554 53.8433C2.80081 53.8484 2.34927 53.9215 1.91532 54.0602C0.816193 54.4243 0.0378782 55.4663 0.11571 56.4289C0.201134 57.469 1.11613 58.4045 2.26652 58.633C2.39494 58.6628 2.52169 58.6996 2.64618 58.7434H28.1673Z" />
                    <path d="M26.4035 0.0949573C25.498 0.46876 24.8336 1.06336 24.4919 2.0182C24.2432 2.71351 24.4615 3.31973 24.9361 3.79812C27.9279 6.81824 30.9342 9.82738 33.955 12.8256C34.2722 13.1354 34.6863 13.3212 35.1245 13.3502C35.5627 13.3793 35.9969 13.2497 36.3507 12.9844C37.4176 12.2368 37.8542 11.3381 37.5429 10.3929C37.4249 10.0732 37.2381 9.78466 36.9962 9.54848C34.0829 6.61488 31.1601 3.69031 28.2278 0.774775C27.9525 0.505559 27.5539 0.154998 27.2521 0.0659053C26.842 -0.0309348 26.6579 -0.0212508 26.4035 0.0949573Z" />
                    <path d="M0 26.852C0.235393 27.2897 0.379666 27.8204 0.721365 28.1535C2.65766 30.1445 4.6528 32.0929 6.62137 34.0588C7.57053 35.0156 8.5197 35.9956 9.48215 36.9408C10.4864 37.9421 11.502 37.8898 12.5935 36.7955C13.6186 35.7625 13.637 34.7528 12.6486 33.7663C9.7631 30.8818 6.87574 27.9953 3.98649 25.1069C3.03732 24.1482 2.01982 24.1598 1.04978 25.1069C0.569498 25.5659 0.12529 26.054 0 26.852Z" />
                    <path d="M15.331 50.1749C12.5082 50.1749 9.68541 50.142 6.8645 50.1943C6.05605 50.2397 5.25697 50.3934 4.48779 50.6514C4.20494 50.7366 3.81958 51.1511 3.83857 51.3873C3.87906 51.564 3.96054 51.7282 4.07616 51.866C4.19178 52.0039 4.33816 52.1114 4.50298 52.1795C5.27036 52.4442 6.07044 52.5975 6.87969 52.6346C12.6012 52.6708 18.3222 52.6708 24.0425 52.6346C24.799 52.6005 25.546 52.449 26.2578 52.1853C26.4251 52.1181 26.5743 52.0115 26.6934 51.8741C26.8125 51.7368 26.8981 51.5726 26.9431 51.3951C26.9678 51.1646 26.5767 50.7443 26.292 50.6552C25.5421 50.3952 24.7611 50.2402 23.9703 50.1943C21.0906 50.142 18.2108 50.1749 15.331 50.1749Z" />
                </g>
                <defs>
                    <clipPath id="clip0_453_377">
                        <rect width="59.7222" height="58.7432" />
                    </clipPath>
                </defs>
            </symbol>

            <symbol id="consultoria-icon" width="40" height="40" viewBox="0 0 60 54" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_453_385)">
                    <path d="M0 26.956C0.0420522 26.5241 0.0727827 26.089 0.127774 25.662C0.207026 25.0329 0.289513 24.4037 0.394644 23.7778C0.430404 23.5208 0.554606 23.2843 0.745887 23.1089C0.937168 22.9336 1.18357 22.8304 1.44271 22.8171C1.87618 22.7669 2.30478 22.686 2.73663 22.6553C3.39329 22.6036 3.69251 22.1927 3.85748 21.6186C4.23989 20.3188 4.748 19.0594 5.3746 17.8581C5.4684 17.6737 5.56868 17.4942 5.65926 17.3082C5.75632 17.1311 5.79918 16.9293 5.7825 16.728C5.76582 16.5267 5.69034 16.3348 5.56545 16.176C5.2824 15.796 4.98642 15.424 4.69367 15.0439C4.29094 14.5312 4.27153 14.054 4.63868 13.5267C6.37213 11.0469 8.52413 8.88776 10.9983 7.14614C11.4997 6.79193 11.9865 6.80972 12.4782 7.18657C12.8421 7.46476 13.2109 7.73972 13.5796 8.01306C13.7541 8.1539 13.968 8.2369 14.1918 8.25052C14.4156 8.26415 14.638 8.20772 14.8283 8.08908C16.2138 7.32085 17.6778 6.70378 19.1952 6.24848C19.7823 6.07542 20.0605 5.69372 20.1204 5.1066C20.1657 4.67314 20.2336 4.2413 20.2821 3.81269C20.2997 3.58027 20.3963 3.36085 20.5557 3.19082C20.7152 3.02079 20.9279 2.91036 21.1587 2.87784C21.644 2.77756 22.1389 2.7161 22.6306 2.64978C24.1457 2.4798 25.6725 2.43652 27.1948 2.52039C28.2461 2.55921 29.2975 2.71124 30.3407 2.84387C31.007 2.93121 31.3111 3.31777 31.3823 4.01648C31.4259 4.44185 31.4923 4.86561 31.544 5.28937C31.6119 5.78591 31.9095 6.07057 32.3721 6.22746C33.0741 6.46683 33.7695 6.72238 34.4747 6.97469C34.6106 7.02321 34.7384 7.09276 34.9114 7.1704C34.2871 7.78339 33.6175 8.33492 33.6482 9.30374C33.5935 9.29762 33.5394 9.2868 33.4865 9.27139C31.9813 8.66401 30.4105 8.23412 28.8058 7.99041C28.5821 7.96791 28.3718 7.87343 28.2065 7.72119C28.0411 7.56895 27.9296 7.36716 27.8887 7.14614C27.782 6.68518 27.6881 6.21937 27.6057 5.75356C27.5151 5.24085 27.3307 5.01765 26.8228 4.93192C26.0959 4.81142 25.3529 4.82623 24.6313 4.97559C24.2382 5.05485 24.1056 5.35568 24.0361 5.70504C23.9455 6.16923 23.8549 6.63504 23.7563 7.09923C23.7205 7.33347 23.6075 7.54904 23.4352 7.71168C23.2629 7.87433 23.0411 7.97471 22.8052 7.99688C21.0406 8.26364 19.3179 8.75726 17.6797 9.46548C16.2741 10.0739 14.9425 10.8406 13.7106 11.7509C13.1397 12.173 12.7661 12.2021 12.1515 11.8317C11.807 11.6263 11.4835 11.3999 11.16 11.1783C10.6554 10.8403 10.1346 10.8775 9.70436 11.3012C9.40837 11.5891 9.11563 11.8802 8.82773 12.1778C8.37163 12.6453 8.34251 13.1483 8.70804 13.6901C8.94256 14.0298 9.17385 14.371 9.39867 14.7188C9.71083 15.204 9.67524 15.6682 9.33721 16.1259C7.52049 18.5764 6.27739 21.4036 5.69969 24.3989C5.63823 24.7223 5.58647 25.0313 5.53795 25.3483C5.51356 25.5791 5.41669 25.7962 5.26123 25.9685C5.10577 26.1408 4.89972 26.2595 4.67265 26.3074C4.21331 26.4222 3.74588 26.5063 3.28007 26.5937C3.01144 26.6293 2.76523 26.7623 2.58814 26.9674C2.41105 27.1725 2.3154 27.4355 2.31934 27.7064C2.30964 28.135 2.31125 28.5637 2.31934 28.9923C2.33228 29.6085 2.7059 30.0145 3.31727 30.1244C3.76206 30.1988 4.2036 30.2862 4.64353 30.3897C4.88041 30.4309 5.09684 30.5498 5.25877 30.7275C5.42069 30.9052 5.51891 31.1318 5.53795 31.3714C5.92031 34.0129 6.81946 36.5532 8.18401 38.847C8.53983 39.4439 8.94095 40.0148 9.33559 40.5873C9.65907 41.0629 9.6995 41.4931 9.39382 41.9751C9.16577 42.3374 8.9183 42.6883 8.67731 43.0425C8.33119 43.5472 8.36839 44.0599 8.79538 44.4982C9.09837 44.812 9.40676 45.1209 9.72053 45.425C9.90171 45.6166 10.1471 45.7349 10.4099 45.7573C10.6727 45.7797 10.9345 45.7046 11.1455 45.5463L12.221 44.8443C12.7192 44.5208 13.1915 44.5597 13.6767 44.9123C16.3502 46.8962 19.4707 48.192 22.7632 48.6856C23.0027 48.7045 23.2295 48.8009 23.4093 48.9602C23.5891 49.1196 23.712 49.3332 23.7595 49.5687C23.8679 50.0378 23.9601 50.5117 24.0425 50.9856C24.125 51.4595 24.311 51.6762 24.8076 51.7571C25.4739 51.8654 26.1533 51.8654 26.8196 51.7571C27.3307 51.6746 27.5216 51.474 27.6121 50.9565C27.693 50.4971 27.7852 50.041 27.8855 49.5849C27.9276 49.3481 28.0466 49.1319 28.2241 48.9696C28.4016 48.8073 28.6276 48.7081 28.8672 48.6873C30.427 48.4536 31.954 48.0378 33.417 47.4483C33.48 47.4241 33.5447 47.4095 33.6531 47.3772C33.6272 48.3476 34.2839 48.9088 34.9082 49.5105C34.8501 49.5493 34.7896 49.5844 34.727 49.6156C33.9814 49.8922 33.2423 50.1914 32.487 50.4243C31.9031 50.6103 31.5828 50.9581 31.5278 51.5662C31.4923 51.9625 31.4324 52.3571 31.3871 52.7518C31.316 53.3648 30.9682 53.7222 30.3568 53.837C28.0899 54.217 25.784 54.3077 23.4942 54.1071C22.7486 54.0505 22.0062 53.9454 21.2639 53.8306C20.6654 53.7448 20.3209 53.3453 20.2595 52.7226C20.2126 52.2746 20.1462 51.8282 20.0848 51.3818C20.0616 51.1666 19.9724 50.9638 19.8293 50.8013C19.6862 50.6389 19.4964 50.5247 19.2858 50.4745C17.952 50.0709 16.658 49.5457 15.4202 48.9056C15.2358 48.8102 15.0531 48.7131 14.8735 48.6129C14.6745 48.4865 14.4403 48.4268 14.205 48.4425C13.9697 48.4582 13.7456 48.5485 13.5651 48.7002C13.1979 48.9768 12.8292 49.2501 12.4636 49.5283C12.2678 49.6993 12.0185 49.7966 11.7587 49.8034C11.4988 49.8101 11.2448 49.726 11.0403 49.5655C8.56457 47.8347 6.40972 45.6853 4.67265 43.214C4.26021 42.6269 4.27962 42.1902 4.72279 41.6241C4.99343 41.2812 5.263 40.9372 5.53148 40.5922C5.67619 40.4256 5.76471 40.2176 5.78445 39.9978C5.8042 39.778 5.75416 39.5576 5.64147 39.3678C4.87041 37.9283 4.24463 36.4156 3.77338 34.8521C3.7205 34.6457 3.60506 34.4608 3.44289 34.3226C3.28072 34.1845 3.07978 34.1 2.86764 34.0806C2.35331 34.0078 1.83574 33.9447 1.32303 33.8606C1.08766 33.8355 0.867945 33.7307 0.700278 33.5636C0.532611 33.3966 0.42706 33.1772 0.401113 32.9419C0.263635 31.9569 0.161739 30.9687 0.0355826 29.9837C0.0258783 29.9077 0.0113217 29.8333 0 29.7589V26.956Z" fill="#6C757D" />
                    <path d="M49.6539 54.7863C46.4887 54.2736 44.7355 51.6033 44.9376 48.9993C45.0165 47.9801 45.3819 47.004 45.9917 46.1836C46.6015 45.3632 47.4308 44.7319 48.384 44.3625C49.3371 43.9932 50.3753 43.9008 51.3787 44.0961C52.3821 44.2913 53.3098 44.7663 54.0548 45.4662C54.7999 46.1661 55.3319 47.0623 55.5895 48.0515C55.8471 49.0408 55.8198 50.0827 55.5107 51.057C55.2016 52.0314 54.6233 52.8985 53.8426 53.5584C53.0619 54.2182 52.1105 54.6439 51.0983 54.7863C50.6224 54.8902 50.1298 54.8902 49.6539 54.7863V54.7863ZM53.9303 49.4053C53.9313 48.6941 53.7213 47.9986 53.327 47.4068C52.9326 46.8149 52.3716 46.3533 51.7149 46.0804C51.0582 45.8074 50.3353 45.7353 49.6376 45.8732C48.9399 46.0111 48.2988 46.3529 47.7954 46.8552C47.2919 47.3575 46.9487 47.9979 46.8092 48.6952C46.6698 49.3926 46.7402 50.1157 47.0117 50.773C47.2832 51.4303 47.7435 51.9924 48.3345 52.388C48.9254 52.7837 49.6205 52.9953 50.3316 52.9959C50.8038 52.9967 51.2715 52.9045 51.7079 52.7245C52.1444 52.5444 52.5411 52.2801 52.8753 51.9466C53.2096 51.6131 53.4748 51.217 53.6558 50.781C53.8368 50.3449 53.9301 49.8774 53.9303 49.4053Z" fill="#6C757D" />
                    <path d="M50.8558 1C51.4941 1.07839 52.1156 1.25916 52.6964 1.53536C54.5289 2.48962 55.5867 3.98571 55.7339 6.05435C55.8022 7.1096 55.5598 8.16175 55.0367 9.08073C54.5135 9.99971 53.7325 10.7452 52.7902 11.2251C51.8479 11.705 50.7856 11.8982 49.7346 11.7809C48.6837 11.6635 47.6902 11.2408 46.877 10.5649C46.0637 9.88897 45.4663 8.98956 45.1587 7.97782C44.8511 6.96609 44.8468 5.88639 45.1462 4.8722C45.4456 3.85801 46.0357 2.95381 46.8435 2.27137C47.6513 1.58892 48.6413 1.15817 49.6913 1.03235C49.7283 1.02475 49.7645 1.01393 49.7996 1L50.8558 1ZM53.9288 6.41503C53.9304 5.70454 53.7215 5.00951 53.3284 4.41768C52.9353 3.82585 52.3756 3.36375 51.7201 3.08973C51.0646 2.8157 50.3426 2.74204 49.6452 2.87803C48.9478 3.01402 48.3064 3.35357 47.8019 3.85382C47.2973 4.35407 46.9523 4.99258 46.8104 5.68875C46.6685 6.38492 46.736 7.10754 47.0044 7.76537C47.2728 8.42321 47.7301 8.98677 48.3186 9.38492C48.907 9.78306 49.6003 9.99793 50.3107 10.0024C50.7841 10.005 51.2533 9.91415 51.6915 9.73517C52.1297 9.55619 52.5283 9.29256 52.8645 8.95935C53.2007 8.62615 53.4679 8.22992 53.6508 7.79333C53.8337 7.35675 53.9288 6.88838 53.9305 6.41503H53.9288Z" fill="#6C757D" />
                    <path d="M59.7223 28.9324C59.6204 29.3464 59.5524 29.7734 59.4117 30.1745C58.9612 31.4151 58.0726 32.4481 56.9134 33.079C55.7541 33.7099 54.4042 33.8951 53.1178 33.5998C51.8315 33.3045 50.6975 32.549 49.9295 31.4757C49.1615 30.4023 48.8124 29.0852 48.9481 27.7724C49.0838 26.4596 49.6948 25.2417 50.6661 24.3481C51.6374 23.4545 52.9019 22.9469 54.2214 22.9209C55.541 22.8948 56.8245 23.3522 57.8302 24.2069C58.836 25.0615 59.4945 26.2544 59.6818 27.5608C59.6931 27.6352 59.7109 27.7096 59.7255 27.784L59.7223 28.9324ZM50.7344 28.3889C50.7424 29.0976 50.9598 29.788 51.3593 30.3734C51.7587 30.9587 52.3224 31.4129 52.9794 31.6786C53.6363 31.9443 54.3572 32.0098 55.0513 31.8668C55.7454 31.7238 56.3817 31.3787 56.8801 30.8749C57.3785 30.3711 57.7168 29.7312 57.8523 29.0356C57.9879 28.34 57.9146 27.6198 57.6418 26.9658C57.3691 26.3117 56.9089 25.7529 56.3193 25.3598C55.7297 24.9666 55.0369 24.7566 54.3283 24.7563C52.3211 24.7498 50.7425 26.3462 50.7344 28.3889V28.3889Z" fill="#6C757D" />
                    <path d="M9.93555 28.3339C10.0099 23.8748 11.595 20.048 14.7877 16.9297C17.0606 14.6868 19.9762 13.2084 23.1286 12.7002C26.6514 12.0767 30.2814 12.6778 33.4152 14.4033C33.494 14.4359 33.5594 14.4943 33.6006 14.569C33.6417 14.6437 33.6562 14.7301 33.6417 14.8141C33.6223 15.0341 33.6417 15.2589 33.6287 15.4789C33.6213 15.5183 33.6046 15.5554 33.5798 15.5869C33.555 15.6185 33.523 15.6435 33.4864 15.66C33.0551 15.7795 32.6693 16.0251 32.3785 16.3652C32.3583 16.3943 32.3324 16.4189 32.3023 16.4376C32.2722 16.4562 32.2386 16.4685 32.2036 16.4737C32.1686 16.4788 32.1329 16.4767 32.0987 16.4675C32.0645 16.4584 32.0326 16.4422 32.0049 16.4202C30.1365 15.4283 28.0534 14.9096 25.938 14.9096C22.1339 14.9096 18.8668 16.2585 16.1932 18.9757C14.2707 20.8968 13.0044 23.3762 12.5751 26.0599C11.9282 29.9901 12.8194 33.563 15.2843 36.6991C17.2166 39.2084 19.9995 40.9249 23.1092 41.5254C26.1273 42.1692 29.2755 41.733 32.0049 40.2929C32.034 40.2701 32.0676 40.2536 32.1035 40.2445C32.1393 40.2354 32.1767 40.2338 32.2132 40.2399C32.2497 40.246 32.2845 40.2596 32.3155 40.2798C32.3465 40.3001 32.3729 40.3266 32.393 40.3576C32.6859 40.6959 33.0744 40.9373 33.5074 41.0499C33.5406 41.0644 33.5698 41.0867 33.5926 41.1148C33.6154 41.1429 33.6311 41.1761 33.6384 41.2116C33.657 41.4868 33.657 41.7629 33.6384 42.0381C33.626 42.0863 33.6036 42.1314 33.5727 42.1704C33.5418 42.2094 33.503 42.2415 33.4589 42.2645C31.9049 43.1308 30.2131 43.7223 28.4579 44.0129C24.8253 44.6065 21.3673 44.0598 18.1616 42.2548C13.8788 39.8417 11.2375 36.1912 10.2364 31.3682C10.0376 30.369 9.93684 29.3527 9.93555 28.3339V28.3339Z" fill="#6C757D" />
                    <path d="M47.2668 27.3036C47.241 27.6271 47.1989 27.9021 47.1989 28.1835C47.1973 28.5203 47.2168 28.8568 47.2571 29.1911C47.2782 29.3658 47.2232 29.4143 47.0663 29.4014C47.0129 29.4014 46.9595 29.4014 46.9045 29.4014C41.6211 29.4014 36.3376 29.4014 31.0541 29.4014C30.8131 29.4014 30.716 29.4645 30.653 29.7038C30.3421 30.9292 29.6113 32.0067 28.5879 32.7487C27.5645 33.4908 26.3132 33.8505 25.0519 33.7651C22.5498 33.626 20.3938 31.6204 20.0607 29.1248C19.6709 26.2022 21.5568 23.5561 24.4551 23.0272C25.8073 22.7758 27.2043 23.0515 28.3596 23.7977C29.5149 24.544 30.3407 25.7041 30.6675 27.04C30.7225 27.26 30.8163 27.3069 31.0266 27.3069C36.3004 27.3069 41.5752 27.3069 46.8512 27.3069L47.2668 27.3036ZM25.4207 24.7578C24.7093 24.7585 24.0141 24.9702 23.423 25.366C22.832 25.7619 22.3717 26.3243 22.1003 26.9819C21.829 27.6395 21.7588 28.3628 21.8987 29.0603C22.0386 29.7578 22.3822 30.3981 22.8862 30.9003C23.3901 31.4024 24.0317 31.7437 24.7297 31.8811C25.4277 32.0185 26.1507 31.9457 26.8073 31.672C27.464 31.3983 28.0246 30.9359 28.4184 30.3434C28.8122 29.751 29.0213 29.055 29.0194 28.3436C29.0192 27.8717 28.9259 27.4044 28.7448 26.9687C28.5637 26.5329 28.2984 26.1371 27.9641 25.804C27.6298 25.4709 27.2331 25.207 26.7966 25.0275C26.3602 24.848 25.8926 24.7564 25.4207 24.7578V24.7578Z" fill="#6C757D" />
                    <path d="M45.2416 42.9924C44.1682 42.9917 43.1191 42.6725 42.2272 42.0752C41.3354 41.4779 40.6408 40.6294 40.2315 39.6371C39.8222 38.6448 39.7166 37.5533 39.9281 36.5009C40.1395 35.4485 40.6585 34.4826 41.4194 33.7254C42.1802 32.9682 43.1486 32.4538 44.202 32.2473C45.2554 32.0409 46.3463 32.1517 47.3367 32.5658C48.327 32.9798 49.1722 33.6784 49.7653 34.5732C50.3583 35.4679 50.6724 36.5185 50.668 37.5919C50.6577 39.0255 50.0819 40.3971 49.0658 41.4084C48.0496 42.4197 46.6753 42.989 45.2416 42.9924ZM45.2594 33.9786C44.5492 33.9754 43.854 34.1829 43.2617 34.5749C42.6694 34.9668 42.2067 35.5256 41.932 36.1806C41.6574 36.8356 41.5831 37.5573 41.7186 38.2544C41.8542 38.9516 42.1934 39.5929 42.6935 40.0973C43.1935 40.6016 43.8319 40.9463 44.5279 41.0878C45.2239 41.2293 45.9462 41.1613 46.6035 40.8922C47.2608 40.6231 47.8235 40.1652 48.2205 39.5763C48.6175 38.9874 48.831 38.294 48.8338 37.5838C48.837 37.1121 48.747 36.6443 48.5689 36.2075C48.3908 35.7706 48.1281 35.3733 47.7959 35.0383C47.4638 34.7033 47.0687 34.4372 46.6334 34.2554C46.1981 34.0735 45.7312 33.9795 45.2594 33.9786V33.9786Z" fill="#6C757D" />
                    <path d="M45.2338 12.7472C46.3059 12.7462 47.3542 13.0637 48.2457 13.6592C49.1372 14.2548 49.8317 15.1016 50.2414 16.0924C50.651 17.0832 50.7571 18.1733 50.5464 19.2245C50.3357 20.2757 49.8176 21.2407 49.0578 21.9971C48.298 22.7535 47.3308 23.2672 46.2786 23.4732C45.2265 23.6792 44.1369 23.5681 43.1479 23.154C42.159 22.74 41.3153 22.0416 40.7237 21.1474C40.1322 20.2533 39.8195 19.2036 39.8253 18.1315C39.8355 16.7024 40.4094 15.3352 41.4222 14.327C42.4349 13.3187 43.8048 12.751 45.2338 12.7472V12.7472ZM48.8358 18.1606C48.8346 17.4584 48.6275 16.7719 48.2401 16.1861C47.8527 15.6004 47.3021 15.1411 46.6564 14.8651C46.0107 14.5891 45.2982 14.5085 44.6071 14.6333C43.916 14.758 43.2767 15.0828 42.7683 15.5672C42.2599 16.0516 41.9047 16.6745 41.7466 17.3587C41.5886 18.043 41.6347 18.7585 41.8792 19.4168C42.1237 20.0751 42.5559 20.6473 43.1222 21.0625C43.6886 21.4777 44.3643 21.7177 45.0656 21.7528C45.5522 21.7772 46.0386 21.7023 46.4953 21.5327C46.9519 21.3631 47.3693 21.1023 47.722 20.7663C48.0747 20.4302 48.3553 20.0259 48.5468 19.5779C48.7383 19.13 48.8366 18.6478 48.8358 18.1606V18.1606Z" fill="#6C757D" />
                    <path d="M43.2829 5.90237C43.2829 5.99618 43.27 6.07705 43.27 6.15954C43.27 6.67711 43.257 7.19791 43.278 7.71547C43.2861 7.9225 43.257 7.9969 43.0306 7.99528C42.0666 7.98342 41.1026 7.98342 40.1387 7.99528C40.0135 8.00051 39.894 8.04911 39.8006 8.13276C39.1645 8.75168 38.5369 9.37923 37.918 10.0154C37.8333 10.1081 37.7845 10.228 37.7805 10.3534C37.7805 11.9708 37.7805 13.5979 37.7805 15.2202V15.6213C37.5088 15.6213 37.2533 15.6213 36.9977 15.6213C36.6306 15.6213 36.2634 15.61 35.8963 15.6116C35.7458 15.6116 35.6747 15.5712 35.6763 15.4029C35.6763 13.4055 35.6763 11.408 35.6763 9.4105C35.6818 9.31347 35.722 9.22164 35.7895 9.15172C36.8397 8.09286 37.8943 7.03778 38.9531 5.98648C39.0253 5.92158 39.1181 5.88434 39.2152 5.88135C40.501 5.88135 41.7868 5.88135 43.0726 5.88135C43.143 5.88456 43.2132 5.89158 43.2829 5.90237V5.90237Z" fill="#6C757D" />
                    <path d="M43.2848 48.7131C43.267 48.9589 43.2363 49.1643 43.2379 49.3681C43.2379 49.7724 43.2525 50.1768 43.28 50.5811C43.2913 50.751 43.2557 50.8124 43.0762 50.8124C41.7903 50.8124 40.5045 50.8124 39.2187 50.8043C39.1152 50.7991 39.0168 50.7579 38.9405 50.6879C37.9038 49.6576 36.8735 48.6192 35.8384 47.589C35.7834 47.5372 35.7405 47.474 35.7125 47.4039C35.6846 47.3338 35.6723 47.2584 35.6766 47.183C35.6766 45.378 35.6766 43.5714 35.6879 41.7647C35.6879 41.734 35.6879 41.7033 35.6879 41.6725C35.6879 41.0078 35.5715 41.1162 36.2443 41.0935C36.6406 41.0806 37.0401 41.0935 37.438 41.0935C37.7776 41.0935 37.7776 41.0935 37.7776 41.4251C37.7776 43.0489 37.7776 44.6717 37.7776 46.2934C37.772 46.3716 37.7836 46.45 37.8115 46.5232C37.8395 46.5964 37.8831 46.6626 37.9393 46.7172C38.562 47.3269 39.1718 47.9513 39.7977 48.5594C39.8956 48.6484 40.0214 48.7005 40.1536 48.7066C41.0949 48.7179 42.0362 48.7066 42.9775 48.7066L43.2848 48.7131Z" fill="#6C757D" />
                    <path d="M31.0975 23.4818L29.5044 22.0747C29.8667 21.7237 30.2403 21.3646 30.6075 20.9991C31.6814 19.9284 32.7489 18.8544 33.8244 17.7902C33.9146 17.703 34.0325 17.6503 34.1576 17.6414C35.4273 17.6317 36.6986 17.6414 37.9682 17.6414C38.0345 17.6414 38.1008 17.6511 38.1591 17.656V19.7586H37.8792C36.946 19.7586 36.0128 19.7586 35.0795 19.7586C35.0044 19.7541 34.9292 19.7663 34.8593 19.7942C34.7894 19.8222 34.7265 19.8652 34.6752 19.9203C33.5387 21.0536 32.3979 22.1868 31.2528 23.3201C31.1994 23.3799 31.1428 23.43 31.0975 23.4818Z" />
                    <path d="M31.1169 33.2137C31.5245 33.6294 31.945 34.0613 32.3704 34.4899C33.1484 35.2695 33.9263 36.0507 34.7124 36.8221C34.8052 36.9053 34.9242 36.9534 35.0488 36.958C36.0192 36.9677 36.9897 36.958 37.9601 36.958C38.096 36.958 38.1881 36.958 38.1849 37.1489C38.172 37.736 38.1849 38.3231 38.1849 38.9086C38.1849 38.9474 38.1849 38.9846 38.1752 39.0703H37.0624C36.092 39.0703 35.1054 39.0703 34.1253 39.0574C34.0287 39.0564 33.9357 39.0209 33.8632 38.9571C32.4486 37.5554 31.0366 36.1439 29.6273 34.7228C29.5901 34.6856 29.5561 34.6435 29.5254 34.6096L31.1169 33.2137Z" />
                </g>
                <defs>
                    <clipPath id="clip0_453_385">
                        <rect width="59.7222" height="53.864" />
                    </clipPath>
                </defs>
            </symbol>

            <symbol id="obras-icon" width="50" height="40" viewBox="0 0 70 45" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_453_431)">
                    <path d="M49.094 34.5139C46.7993 30.6904 44.9751 29.5301 42.4743 30.0721C39.7154 30.6709 38.3976 32.4821 37.6722 36.9304C29.1958 37.3735 21.367 35.4146 14.2815 30.593C14.2068 30.5427 14.1371 30.4876 14.0673 30.4308C6.4251 24.3108 6.44944 25.1223 10.7468 16.0471C16.2468 4.43536 28.1296 -1.67319 39.8387 0.39924C48.44 1.92313 53.8637 7.26405 57.09 15.0815C57.9498 17.2248 58.6442 19.4308 59.1673 21.6801C60.3666 26.6462 59.8262 28.1181 55.5272 31.0247C53.5553 32.3539 51.3385 33.313 49.094 34.5139ZM45.2186 8.17936C35.319 3.92902 23.8549 11.7497 22.1963 19.1176C28.3698 11.6491 35.8529 7.92294 45.2186 8.17936ZM17.4851 14.963C23.5709 8.0479 31.0053 4.22925 40.9991 4.81674C32.9609 0.425207 20.3349 6.12641 17.4851 14.963Z" />
                    <path d="M4.85978 26.3199C10.9716 34.647 19.4885 37.8424 29.0408 39.1764C38.6613 40.5186 47.5417 38.7058 55.8898 33.61C54.9372 34.4214 54.0397 35.301 53.0206 36.0134C45.4904 41.2781 37.1163 44.4167 27.9648 44.8549C17.4031 45.3596 8.71739 40.7977 1.20667 33.6846C-0.448678 32.1169 -0.41622 30.6725 1.36895 29.2428C2.48226 28.3599 3.54525 27.4268 4.85978 26.3199Z" />
                </g>
                <defs>
                    <clipPath id="clip0_453_431">
                        <rect width="59.7222" height="44.8923" />
                    </clipPath>
                </defs>
            </symbol>
            
            <symbol id="denunciation-icon" width="50" height="50" viewBox="0 0 1296.000000 1072.000000" preserveAspectRatio="xMidYMid meet">
                <g transform="translate(0.000000,1072.000000) scale(0.100000,-0.100000)" stroke="none">
                    <path d="M6110 10714 c-155 -9 -364 -26 -470 -40 -1120 -142 -2091 -591 -2947
  -1366 -267 -242 -697 -742 -818 -950 l-27 -48 74 0 c86 0 85 -1 187 142 165
  232 424 523 646 727 158 145 328 288 361 303 18 9 59 -14 295 -162 151 -95
  280 -178 288 -185 11 -11 -8 -39 -116 -167 -149 -176 -325 -396 -438 -548
  l-78 -105 79 -3 79 -3 35 38 c19 22 83 100 142 175 196 248 439 538 452 538 7
  0 58 -21 112 -46 162 -76 378 -160 564 -219 96 -31 192 -64 212 -73 l37 -17
  -64 -142 c-35 -78 -72 -167 -84 -198 l-21 -56 72 3 72 3 76 169 c41 93 83 174
  92 180 13 8 72 0 235 -32 345 -67 547 -93 881 -111 84 -4 155 -11 159 -14 3
  -4 8 -49 11 -102 l5 -95 62 0 63 0 4 94 c1 52 5 97 8 100 3 3 118 12 255 21
  368 22 635 55 893 110 40 8 86 15 102 15 32 0 26 10 130 -222 l52 -118 69 0
  c38 0 69 3 69 6 0 3 -34 87 -76 186 -59 141 -73 183 -62 189 7 5 58 23 113 39
  210 64 431 143 593 212 237 101 217 102 330 -29 51 -59 181 -219 288 -355
  l196 -248 79 0 c43 0 79 3 79 7 0 14 -262 352 -434 561 -97 117 -176 216 -175
  220 0 11 613 387 635 390 35 5 355 -269 549 -470 126 -130 241 -266 444 -525
  l142 -183 75 0 c89 0 92 -14 -37 171 -635 907 -1613 1624 -2699 1977 -383 125
  -793 207 -1206 242 -132 11 -540 20 -644 14z m790 -163 c332 -41 666 -109 657
  -134 -7 -24 -166 -129 -282 -187 -202 -100 -412 -161 -668 -195 -136 -17 -441
  -20 -567 -5 -309 38 -639 149 -842 283 -95 62 -131 94 -125 110 7 22 336 88
  602 122 223 28 349 33 705 30 280 -3 390 -8 520 -24z m-1911 -257 c45 -37 78
  -71 74 -75 -5 -4 -102 -71 -218 -149 -388 -263 -655 -473 -892 -702 -102 -100
  -135 -126 -150 -121 -39 15 -473 283 -515 318 l-28 24 43 34 c150 121 539 348
  817 477 215 100 613 249 725 272 33 7 59 -7 144 -78z m2993 10 c355 -121 629
  -243 908 -403 131 -75 390 -242 448 -289 23 -18 23 -19 5 -40 -18 -22 -576
  -362 -594 -362 -5 0 -55 46 -112 103 -250 250 -504 453 -955 762 -141 96 -171
  121 -160 131 7 7 56 47 108 88 73 59 101 76 126 76 18 0 119 -30 226 -66z
  m-2684 -200 c31 -15 104 -46 162 -69 57 -24 106 -47 108 -53 2 -6 -44 -79
  -102 -164 -332 -485 -452 -668 -521 -793 -42 -77 -83 -150 -91 -162 l-14 -22
  -72 20 c-258 70 -808 283 -808 313 0 14 199 208 305 297 146 122 245 195 688
  503 258 180 247 175 345 130z m2338 -166 c289 -199 474 -335 617 -455 135
  -113 337 -313 337 -334 0 -44 -717 -308 -850 -312 l-44 -2 -64 115 c-151 271
  -301 505 -527 820 -65 90 -120 172 -122 181 -4 13 31 31 174 87 98 39 189 71
  204 71 17 1 106 -54 275 -171z m-1781 -12 c44 -8 134 -20 199 -27 91 -9 124
  -17 138 -31 17 -17 18 -48 16 -611 l-3 -592 -190 1 c-196 1 -355 16 -634 60
  -157 24 -355 68 -379 83 -11 7 -9 18 12 58 42 85 166 293 229 388 152 227 451
  647 474 665 31 24 35 24 138 6z m957 -7 c69 -32 572 -778 713 -1058 25 -51 26
  -56 10 -67 -96 -71 -1149 -181 -1185 -124 -6 9 -10 246 -10 596 0 456 3 584
  13 598 10 14 43 20 180 32 93 8 185 18 205 23 51 12 48 12 74 0z" />
                    <path d="M10180 7789 c-186 -12 -311 -27 -450 -55 -635 -126 -1124 -431 -1435
  -895 -81 -120 -194 -354 -244 -503 -179 -538 -201 -1231 -56 -1783 163 -622
  528 -1078 1086 -1359 394 -197 816 -288 1349 -288 640 0 1154 138 1590 429
  636 424 952 1134 927 2080 -12 452 -92 797 -266 1150 -214 433 -533 744 -986
  961 -454 217 -935 301 -1515 263z m489 -1170 c199 -30 325 -127 422 -324 96
  -198 138 -434 146 -835 15 -710 -83 -1120 -307 -1284 -119 -88 -214 -110 -485
  -110 -162 -1 -215 3 -280 18 -270 63 -417 255 -479 626 -34 204 -41 309 -41
  650 1 342 9 476 41 670 57 339 195 521 438 575 146 32 380 38 545 14z" />
                    <path d="M4845 7773 c-508 -42 -889 -196 -1161 -467 -201 -201 -321 -438 -371
  -736 -20 -120 -22 -396 -4 -500 76 -429 377 -808 821 -1030 204 -103 408 -172
  1235 -421 292 -88 571 -174 620 -191 201 -68 345 -159 345 -219 0 -71 -146
  -162 -325 -202 -87 -19 -131 -22 -330 -22 -203 0 -243 3 -345 24 -240 49 -467
  139 -645 256 -150 98 -259 204 -408 398 -16 21 -41 40 -61 45 -20 6 -208 8
  -460 4 l-426 -5 0 -843 0 -844 23 -5 c35 -9 974 -1 984 8 4 5 9 79 11 165 2
  86 7 161 12 166 5 5 27 -2 52 -17 107 -62 474 -239 573 -276 385 -142 760
  -189 1171 -146 560 59 1037 275 1284 582 212 263 304 523 304 858 -1 231 -40
  432 -119 603 -141 305 -488 615 -888 794 -160 72 -324 125 -992 318 -661 191
  -784 230 -870 272 -190 93 -233 194 -124 292 52 47 79 60 189 87 80 20 121 23
  260 23 194 0 308 -14 486 -59 159 -41 280 -87 445 -172 195 -99 339 -215 505
  -406 l41 -47 441 0 c242 0 448 3 456 6 15 6 16 74 16 723 0 394 -3 748 -7 787
  l-5 71 -257 6 c-262 6 -684 -3 -696 -15 -3 -3 -9 -65 -12 -137 -3 -72 -8 -131
  -11 -131 -2 0 -99 47 -216 104 -352 174 -643 258 -1025 296 -94 9 -420 11
  -516 3z" />
                    <path d="M28 7729 c-17 -9 -18 -46 -18 -555 l0 -544 26 -10 c14 -6 158 -10
  334 -10 296 0 310 -1 320 -19 7 -13 10 -415 10 -1230 l0 -1210 -22 -15 c-19
  -14 -69 -16 -345 -16 l-323 0 0 -550 c0 -533 1 -550 19 -560 13 -7 491 -10
  1474 -10 1216 0 1456 2 1466 14 8 9 10 164 9 557 l-3 544 -328 5 c-312 5 -329
  6 -343 25 -22 30 -16 2441 6 2455 9 6 144 10 317 10 171 0 313 4 327 10 l26
  10 0 544 c0 529 -1 546 -19 556 -27 14 -2909 13 -2933 -1z" />
                    <path d="M1850 2417 c0 -16 109 -178 210 -312 132 -176 287 -352 465 -531
  1277 -1279 3081 -1821 4870 -1462 657 131 1282 390 1845 763 252 167 495 356
  708 552 260 239 719 777 805 945 l28 53 -52 3 c-85 5 -100 -7 -223 -172 -172
  -232 -303 -384 -506 -586 -162 -162 -379 -356 -453 -405 -24 -15 -32 -11 -353
  186 -181 111 -332 206 -336 212 -4 6 5 26 20 43 229 275 351 428 451 560 l120
  159 -60 3 c-94 5 -117 -12 -244 -174 -60 -77 -173 -217 -251 -310 -77 -93
  -148 -181 -158 -196 l-17 -26 -145 64 c-192 84 -403 162 -594 218 -162 48
  -210 65 -210 73 0 3 31 80 70 172 38 92 70 170 70 174 0 4 -29 7 -63 7 -76 0
  -81 -5 -122 -105 -46 -112 -94 -205 -111 -212 -9 -3 -117 13 -242 35 -300 54
  -332 57 -860 91 -83 6 -149 14 -158 21 -10 9 -14 34 -14 86 l0 74 -65 0 -65 0
  0 -68 c0 -95 -8 -104 -106 -109 -368 -18 -435 -26 -881 -105 -231 -40 -295
  -49 -307 -39 -8 7 -42 76 -77 154 -34 78 -69 150 -77 160 -11 12 -30 17 -73
  17 -32 0 -60 -3 -62 -7 -2 -5 31 -89 73 -188 43 -99 75 -183 71 -186 -3 -4
  -60 -23 -126 -44 -211 -65 -375 -125 -575 -212 -107 -47 -202 -86 -212 -87
  -21 -1 -140 135 -389 446 -111 139 -209 259 -217 266 -10 7 -46 12 -94 12
  l-79 0 93 -122 c114 -152 338 -430 452 -563 47 -55 86 -103 86 -106 0 -8 -597
  -389 -608 -389 -14 0 -192 147 -332 274 -210 191 -346 344 -620 696 -79 102
  -150 191 -159 198 -21 17 -141 16 -141 -1z m4341 -317 c18 -10 19 -28 19 -598
  0 -463 -3 -592 -13 -606 -10 -13 -51 -22 -192 -41 -99 -13 -198 -26 -220 -30
  -32 -5 -45 -3 -66 14 -59 46 -415 557 -576 826 -81 135 -153 266 -153 279 0
  14 56 28 265 64 369 65 417 71 720 95 95 8 198 6 216 -3z m514 0 c316 -24 722
  -84 843 -125 25 -9 -140 -298 -341 -600 -116 -173 -327 -467 -365 -507 -31
  -34 -35 -34 -262 -8 -96 11 -183 20 -192 20 -9 0 -24 7 -32 16 -14 14 -16 81
  -16 595 0 381 4 587 10 600 10 17 22 19 113 19 56 0 165 -5 242 -10z m1186
  -209 c286 -84 709 -247 709 -273 0 -17 -184 -199 -304 -302 -148 -126 -306
  -245 -608 -456 -263 -183 -312 -213 -343 -204 -33 10 -297 113 -337 132 l-37
  17 125 175 c246 344 408 594 519 805 32 61 65 118 73 128 22 25 54 22 203 -22z
  m-2975 -103 c137 -251 259 -440 500 -778 84 -118 154 -219 154 -225 1 -14
  -328 -155 -362 -155 -38 0 -435 267 -718 483 -191 146 -456 378 -505 443 l-25
  33 42 25 c143 82 724 293 815 295 30 1 34 -4 99 -121z m3941 -289 c187 -104
  533 -325 533 -342 0 -14 -36 -42 -200 -151 -368 -246 -756 -438 -1198 -592
  -187 -66 -215 -67 -274 -16 -24 20 -81 66 -126 102 l-82 65 22 17 c13 10 100
  70 193 134 375 258 631 462 860 685 77 75 147 138 155 141 19 6 43 -3 117 -43z
  m-4908 -101 c234 -227 491 -429 899 -708 116 -80 212 -148 212 -152 0 -4 -44
  -45 -97 -93 -84 -74 -102 -85 -134 -85 -20 0 -101 22 -180 49 -459 156 -856
  354 -1255 622 -158 106 -163 112 -139 139 28 31 537 350 558 350 5 0 66 -55
  136 -122z m2681 -674 c238 -33 484 -109 681 -211 101 -52 279 -176 286 -199 9
  -29 -361 -104 -747 -151 -184 -23 -854 -26 -1045 -5 -302 33 -747 117 -783
  148 -8 6 68 69 153 126 375 251 932 363 1455 292z" />
                </g>
            </symbol>
            
        </svg>

        <!-- END SVG'S -->

        <!-- SCRIPTS -->
        <!-- Dynamic Scripts -->


        <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.14.2/TweenMax.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>

        

                    <script src="/app/assets/markdown/markdown.js"></script>
        
        <script src="/app/assets/js/main.js"></script>

        <!-- Apexcharts -->
        <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
        <script src="/app/assets/js/accesibility.js"></script>
        </div>
        </body>

        </html>
